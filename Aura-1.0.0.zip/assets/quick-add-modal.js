if (!customElements.get("quick-add-modal")) {
  customElements.define(
    "quick-add-modal",
    class QuickAddModal extends ModalDialog {
      constructor() {
        super();
        this.modalContent = this.querySelector('[id^="QuickAddInfo-"]');
      }

      hide(preventFocus = false) {
        const cartNotification = document.querySelector("cart-drawer");
        if (cartNotification) cartNotification.setActiveElement(this.openedBy);
        this.modalContent.innerHTML = "";

        if (preventFocus) this.openedBy = null;
        super.hide();
      }

      show(opener) {
        opener.setAttribute("aria-disabled", true);
        opener.classList.add("loading");
        opener.querySelector(".loading__spinner ").classList.remove("hidden");

        fetch(opener.getAttribute("data-product-url"))
          .then((response) => response.text())
          .then((responseText) => {
            const responseHTML = new DOMParser().parseFromString(
              responseText,
              "text/html"
            );
            this.productElement = responseHTML.querySelector(
              'section[id^="MainProduct-"]'
            );
            this.productElement.classList.forEach((classApplied) => {
              if (
                classApplied.startsWith("color-") ||
                classApplied === "gradient"
              )
                this.modalContent.classList.add(classApplied);
            });
            this.blockDuplicateIDs();
            this.clearDOMElements();
            this.updateHTMLContent(
              this.modalContent,
              this.productElement.innerHTML
            );

            if (window.Shopify && Shopify.PaymentButton) {
              Shopify.PaymentButton.init();
            }

            if (window.ProductModel) window.ProductModel.loadShopifyXR();

            this.removeGalleryMetadata();
            this.refreshImageSizes();
            this.preventURLVariantChange();
            super.show(opener);
          })
          .finally(() => {
            opener.removeAttribute("aria-disabled");
            opener.classList.remove("loading");
            opener.querySelector(".loading__spinner ").classList.add("hidden");
          });
      }

      // updateHTMLContent

      updateHTMLContent(element, html) {
        // Clear existing content
        element.innerHTML = "";
        // Insert the new HTML content
        element.insertAdjacentHTML("beforeend", html);

        // Reinjects scripts
        element.querySelectorAll("script").forEach((oldScriptTag) => {
          const newScriptTag = document.createElement("script");
          Array.from(oldScriptTag.attributes).forEach((attribute) => {
            newScriptTag.setAttribute(attribute.name, attribute.value);
          });
          newScriptTag.appendChild(
            document.createTextNode(oldScriptTag.innerHTML)
          );
          oldScriptTag.parentNode.replaceChild(newScriptTag, oldScriptTag);
        });
      }

      // preventURLVariantChange

      preventURLVariantChange() {
        this.modalContent
          .querySelector("variant-picker")
          ?.setAttribute("data-update-url", "false");
      }

      // clearDOMElements

      clearDOMElements() {
        this.productElement.querySelector("pickup-availability")?.remove();
       
        this.productElement
          .querySelectorAll("modal-dialog")
          .forEach((modal) => modal.remove());
      }

      // blockDuplicateIDs

      blockDuplicateIDs() {
        const sectionId = this.productElement.dataset.section;

        // Create a temporary wrapper to handle replacement
        const tempWrapper = document.createElement("div");
        tempWrapper.innerHTML = this.productElement.innerHTML.replaceAll(
          sectionId,
          `quickadd-${sectionId}`
        );

        // Update the productElement's innerHTML
        this.productElement.innerHTML = tempWrapper.innerHTML;

        // Add the original section ID to relevant elements
        this.productElement
          .querySelectorAll("variant-picker, product-object")
          .forEach((element) => {
            element.dataset.originalSection = sectionId;
          });
      }

      // removeGalleryMetadata

      removeGalleryMetadata() {
        try {
          const galleryList = this.modalContent.querySelector(
            '[id^="Slider-Gallery"]'
          );
          if (!galleryList) return;

          galleryList.setAttribute("role", "presentation");
          galleryList
            .querySelectorAll('[id^="Slide-"]')
            .forEach((li) => li.setAttribute("role", "presentation"));
        } catch (error) {
          console.error("Error removing gallery metadata:", error);
        }
      }

      // refreshImageSizes

      setMediaImageSizes(product, mediaImages) {
        let mediaImageSizes =
          "(min-width: 1000px) 715px, (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw - 4rem)";

        if (product.classList.contains("product--medium")) {
          mediaImageSizes = mediaImageSizes.replace("715px", "605px");
        } else if (product.classList.contains("product--small")) {
          mediaImageSizes = mediaImageSizes.replace("715px", "495px");
        }

        mediaImages.forEach((img) =>
          img.setAttribute("sizes", mediaImageSizes)
        );
      }

      refreshImageSizes() {
        const product = this.modalContent.querySelector(".product");
        if (!product?.classList.contains("product--columns")) return;

        const mediaImages = product.querySelectorAll(".product__media img");
        if (!mediaImages.length) return;

        this.setMediaImageSizes(product, mediaImages);
      }
    }
  );
}
