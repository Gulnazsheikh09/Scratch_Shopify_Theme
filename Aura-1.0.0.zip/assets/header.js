// SEARCH POPUP
document
  .querySelector(".header_search.search_right, .header_search.search_left")
  .addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector(".main_search_wrapper").classList.add("active");
    const container = document.querySelector(".main_search_wrapper");
    const inner = container.querySelector(".main_search_inner");
    document.querySelector('aside#main-collection-filters').style.zIndex = '2';
    trapFocus(container, inner);
  });

document
  .querySelector(".header_search.search_right")
  .addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector(".main_search_wrapper").classList.add("active");
    const container = document.querySelector(".main_search_wrapper");
    const inner = container.querySelector(".main_search_inner");
    document.querySelector('aside#main-collection-filters').style.zIndex = '2';
    trapFocus(container, inner);
  });

document
  .querySelector(".main_search_close")
  .addEventListener("click", function () {
    var closestWrapper = this.closest(".main_search_wrapper");
    if (closestWrapper) {
      closestWrapper.classList.remove("active");
    }
    const searchLeft = document.querySelector(".header_search.search_left");
    const searchRight = document.querySelector(".header_search.search_right");
    const container = document.querySelector(".main_search_wrapper");
    const inner = container.querySelector(".main_search_inner");
    setTimeout(()=>{
        document.querySelector('aside#main-collection-filters').style.zIndex = '6';                
      },500)
    removeTrapFocus(searchLeft);
    removeTrapFocus(searchRight);
  });

document
  .querySelector(".main_search_wrapper")
  .addEventListener("keydown", closeOnEscape);

function closeOnEscape(event) {
  if (event.key === "Escape") {
    const container = document.querySelector(".main_search_wrapper");
    const inner = container.querySelector(".main_search_inner");
    const searchLeft = document.querySelector(".header_search.search_left");
    const searchRight = document.querySelector(".header_search.search_right");
    setTimeout(()=>{
        document.querySelector('aside#main-collection-filters').style.zIndex = '6';                
      },500)
    removeTrapFocus(searchLeft);
    removeTrapFocus(searchRight);
    //searchLeft.focus();
    container.classList.remove("active");
  }
}

document
  .querySelector(".main_search_wrapper")
  .addEventListener("click", function () {
    this.classList.remove("active");
  });

document
  .querySelector(".main_search_inner")
  .addEventListener("click", function (e) {
    e.stopPropagation();
  });

document
  .querySelector(".main_search_inner")
  .addEventListener("mouseover", function (e) {
    let cursor = document.querySelector(".cursor");
    cursor.style.transform = "translate(-50%,-50%)";
    cursor.style.scale = "0";
  });

document
  .querySelector(".main_search_inner")
  .addEventListener("mouseleave", function (e) {
    let cursor = document.querySelector(".cursor");
    let left = e.clientX + "px";
    let top = e.clientY + "px";
    cursor.style.left = left;
    cursor.style.top = top;
    cursor.style.transform = "translate(-50%,-50%)";
    cursor.style.scale = "1";
  });

//MOBILE DRAWER
document
  .querySelector(".mobile_menu_btn")
  .addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector(".mobile_drawer_wrapper").classList.add("active");
    let Drawer = document.querySelector(".mobile_drawer_wrapper");
    let DrawerInner = Drawer.querySelector(".mobile_drawer_inner");
    document.querySelector('aside#main-collection-filters').style.zIndex = '2';
    trapFocus(Drawer, DrawerInner);
  });

document
  .querySelector(".mobile_drawer_close")
  .addEventListener("click", function () {
    var closestWrapper = this.closest(".mobile_drawer_wrapper");
    if (closestWrapper) {
      closestWrapper.classList.remove("active");
      setTimeout(()=>{
        document.querySelector('aside#main-collection-filters').style.zIndex = '6';                
      },500)
    }
    let Wrapper = document.querySelector(".mobile_menu_btn");
    removeTrapFocus(Wrapper);
  });

document
  .querySelector(".mobile_drawer_wrapper")
  .addEventListener("keydown", closeOn);

function closeOn(event) {
  if (event.key === "Escape") {
    const container = document.querySelector(".mobile_drawer_wrapper");
    const inner = container.querySelector(".mobile_drawer_inner");
    const menuBtn = document.querySelector(".mobile_menu_btn");
    removeTrapFocus(menuBtn);
    container.classList.remove("active");
  }
}

// SEARCH DRAWER ACCESSIBILITY

document.addEventListener("DOMContentLoaded", function () {
  const searchIcons = document.querySelectorAll(".header_search"); // Search icons
  const searchDrawer = document.querySelector(".main_search_wrapper"); // Update with actual ID
  const DrawerInner = searchDrawer.querySelector(".main_search_inner");
  const focusableElements = searchDrawer.querySelectorAll("button, input, a"); // Interactive elements
  const closeButton = searchDrawer.querySelector(".main_search_close"); // Update selector

  function disableSearchFocus() {
    focusableElements.forEach((el) => el.setAttribute("tabindex", "-1"));
  }

  function openSearchDrawer(event) {
    if (event.key === "Enter" || event.keyCode === 13) {
      event.preventDefault();
      searchDrawer.classList.add("active");
      searchDrawer.setAttribute("aria-hidden", "false");

      // Enable focus
      focusableElements.forEach((el) => el.setAttribute("tabindex", "0"));
      trapFocus(searchDrawer, DrawerInner);
    }
  }

  function closeSearchDrawer() {
    searchDrawer.classList.remove("active");
    searchDrawer.setAttribute("aria-hidden", "true");

    // Disable focus
    disableSearchFocus();

    // Return focus to the search icon
    searchIcons[0].focus();
  }

  // Apply tabindex="-1" initially
  disableSearchFocus();

  // Event Listeners
  searchIcons.forEach((icon) => {
    icon.addEventListener("keydown", openSearchDrawer);
  });

  closeButton.addEventListener("click", closeSearchDrawer);
  searchDrawer.addEventListener("keydown", function (event) {
    if (event.key === "Escape" || event.keyCode === 27) {
      closeSearchDrawer();
    }
  });
});

// MOBILE DRAWER ACCESSIBILITY

document.addEventListener("DOMContentLoaded", function () {
  const menuBtn = document.querySelectorAll(".mobile_menu_btn");
  const menuDrawer = document.querySelector(".mobile_drawer_wrapper"); // Update with actual ID
  const menuInner = menuDrawer.querySelector(".mobile_drawer_inner");
  const focusableElements = menuDrawer.querySelectorAll("button, input, a"); // Interactive elements
  const closeButton = menuDrawer.querySelector(".mobile_drawer_close"); // Update selector

  function disableMenuFocus() {
    focusableElements.forEach((el) => el.setAttribute("tabindex", "-1"));
  }

  function openMenuDrawer(event) {
    if (event.key === "Enter" || event.keyCode === 13) {
      event.preventDefault();
      menuDrawer.classList.add("active");
      menuDrawer.setAttribute("aria-hidden", "false");

      // Enable focus
      focusableElements.forEach((el) => el.setAttribute("tabindex", "0"));
      trapFocus(menuDrawer, menuInner);
    }
  }

  function closeMenuDrawer() {
    menuDrawer.classList.remove("active");
    menuDrawer.setAttribute("aria-hidden", "true");

    // Disable focus
    disableMenuFocus();

    // Return focus to the search icon
    menuBtn[0].focus();
  }

  // Apply tabindex="-1" initially
  disableMenuFocus();

  // Event Listeners
  menuBtn.forEach((icon) => {
    icon.addEventListener("keydown", openMenuDrawer);
  });

  closeButton.addEventListener("click", closeMenuDrawer);
  menuDrawer.addEventListener("keydown", function (event) {
    if (event.key === "Escape" || event.keyCode === 27) {
      closeMenuDrawer();
    }
  });
});

const parents = document.querySelectorAll(".has_megamenu .parent_a");
const links = document.querySelectorAll(".mega_menu_link");
const images = document.querySelectorAll(".mega_menu_image a");

parents.forEach((parent) => {
  parent.addEventListener("focus", () => {
    parent
      .closest(".has_megamenu_inner")
      .nextElementSibling.classList.add("active");
  });

  parent.addEventListener("blur", () => {
    parent
      .closest(".has_megamenu_inner")
      .nextElementSibling.classList.remove("active");
  });
});

links.forEach((link) => {
  link.addEventListener("focus", () => {
    link.closest(".main_mega__menu_wrapper").classList.add("active");
  });

  link.addEventListener("blur", () => {
    link.closest(".main_mega__menu_wrapper").classList.remove("active");
  });
});

images.forEach((image) => {
  image.addEventListener("focus", () => {
    image.closest(".main_mega__menu_wrapper").classList.add("active");
  });

  image.addEventListener("blur", () => {
    image.closest(".main_mega__menu_wrapper").classList.remove("active");
  });
});
