class PredictiveSearch extends HTMLElement {
  constructor() {
    super();

    this.input = this.querySelector('input[type="search"]');
    this.resetButton = this.querySelector('button[type="reset"]');
    this.predictiveSearchResults = this.querySelector("#predictive-search");
    this.emptySearch = this.querySelector(".empty_search_wrapper");

    if (this.input) {
      this.input.form.addEventListener("reset", this.onFormReset.bind(this));
      this.input.addEventListener(
        "input",
        this.debounce((event) => {
          this.onChange(event);
        }, 300).bind(this)
      );
    }
  }

  toggleResetButton() {
    const resetIsHidden = this.resetButton.classList.contains("hidden");
    if (this.input.value.length > 0 && resetIsHidden) {
      this.resetButton.classList.remove("hidden");
    } else if (this.input.value.length === 0 && !resetIsHidden) {
      this.resetButton.classList.add("hidden");
    }
  }

  onFormReset(event) {
    // Prevent default so the form reset doesn't set the value gotten from the url on page load
    event.preventDefault();
    // Don't reset if the user has selected an element on the predictive search dropdown
    this.input.value = "";
    this.input.focus();
    this.toggleResetButton();
    this.close();
  }

  onChange() {
    const searchTerm = this.input.value.trim();

    if (!searchTerm.length) {
      this.close();
      this.toggleResetButton();

      return;
    }

    this.getSearchResults(searchTerm);
    this.toggleResetButton();
  }

  getSearchResults(searchTerm) {
    fetch(`/search/suggest?q=${searchTerm}&section_id=predictive-search`)
      .then((response) => {
        if (!response.ok) {
          var error = new Error(response.status);
          this.close();
          throw error;
        }

        return response.text();
      })
      .then((text) => {
        const resultsMarkup = new DOMParser()
          .parseFromString(text, "text/html")
          .querySelector("#shopify-section-predictive-search").innerHTML;
        this.predictiveSearchResults.innerHTML = resultsMarkup;
        this.open();
        // BUTTON HOVER
        const btns = document.querySelectorAll(".btn");

        btns.forEach(function (btn) {
          btn.addEventListener("mouseenter", function (e) {
            const parentOffset = btn.getBoundingClientRect();
            const relX = e.clientX - parentOffset.left;
            const relY = e.clientY - parentOffset.top;

            const span = btn.querySelector("span");
            span.style.top = `${relY}px`;
            span.style.left = `${relX}px`;
          });

          btn.addEventListener("mouseout", function (e) {
            const parentOffset = btn.getBoundingClientRect();
            const relX = e.clientX - parentOffset.left;
            const relY = e.clientY - parentOffset.top;
            const span = btn.querySelector("span");
            span.style.top = `${relY}px`;
            span.style.left = `${relX}px`;
          });
        });
      })
      .catch((error) => {
        this.close();
        this.toggleResetButton();

        throw error;
      });
  }

  open() {
    this.predictiveSearchResults.style.display = "block";
    if(this.emptySearch) {
      this.emptySearch.style.display = "none";      
    }
  }

  close() {
    this.predictiveSearchResults.style.display = "none";
    if(this.emptySearch) {
      this.emptySearch.style.display = "block";      
    }
  }

  debounce(fn, wait) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }
}

customElements.define("predictive-search", PredictiveSearch);
