class LocalizationForm extends HTMLElement {
  constructor() {
    super();
    let input = this.querySelector(
      'input[name="language_code"], input[name="country_code"]'
    );
    let listItems = this.querySelectorAll(".country_selector_ul li");
    let form = this.querySelector("form");
    listItems.forEach(function (listItem) {
      listItem.addEventListener("click", function (event) {
        event.preventDefault();
        let value = listItem.getAttribute("data-value");
        input.value = value;
        if (form) form.submit();
      });
    });
  }
}

customElements.define("localization-form", LocalizationForm);

// document.addEventListener("DOMContentLoaded", function () {
//   const LocalizationBtn = document.querySelectorAll(".localization_selectors");
//   const LocalizationDrawer = document.querySelector(
//     ".main_localization_wrapper"
//   ); // Update with actual ID
//   const LocalizationInner = LocalizationDrawer.querySelector(
//     ".main_localization_inner"
//   );
//   const focusableElements =
//     LocalizationDrawer.querySelectorAll("button, input, a"); // Interactive elements
//   const closeButton = LocalizationDrawer.querySelector(".localization_close"); // Update selector

//   function disableLocalizationFocus() {
//     focusableElements.forEach((el) => el.setAttribute("tabindex", "-1"));
//   }

//   function openLocalizationDrawer(event) {
//     if (event.key === "Enter" || event.keyCode === 13) {
//       event.preventDefault();
//       LocalizationDrawer.classList.add("active");
//       LocalizationDrawer.setAttribute("aria-hidden", "false");
//       document.querySelector(
//         ".section-header.shopify-section-group-header-group"
//       ).style.zIndex = "2";

//       // Enable focus
//       focusableElements.forEach((el) => el.setAttribute("tabindex", "0"));
//       trapFocus(LocalizationDrawer, LocalizationInner);
//     }
//   }

//   function closeLocalizationDrawer() {
//     LocalizationDrawer.classList.remove("active");
//     LocalizationDrawer.setAttribute("aria-hidden", "true");
//     document.querySelector(
//       ".section-header.shopify-section-group-header-group"
//     ).style.zIndex = "3";

//     // Disable focus
//     disableLocalizationFocus();

//     // Return focus to the localization icon
//     //LocalizationBtn[0].focus();
//     LocalizationBtn.forEach((btn) => {
//       btn.focus();
//     });
//   }

//   // Apply tabindex="-1" initially
//   disableLocalizationFocus();

//   // Event Listeners
//   LocalizationBtn.forEach((icon) => {
//     icon.addEventListener("keydown", openLocalizationDrawer);
//   });

//   closeButton.addEventListener("click", closeLocalizationDrawer);
//   LocalizationDrawer.addEventListener("keydown", function (event) {
//     if (event.key === "Escape" || event.keyCode === 27) {
//       closeLocalizationDrawer();
//     }
//   });
// });

document.addEventListener("DOMContentLoaded", function () {
  const localizationButtons = document.querySelectorAll(
    ".localization_selectors"
  );
  const localizationDrawer = document.querySelector(
    ".main_localization_wrapper"
  );
  const localizationInner = localizationDrawer?.querySelector(
    ".main_localization_inner"
  );
  const focusableElements = localizationDrawer
    ? Array.from(localizationDrawer.querySelectorAll("button, input, a"))
    : [];
  const closeButton = localizationDrawer?.querySelector(".localization_close");
  let lastFocusedButton = null; // Track which button opened the drawer

  function disableLocalizationFocus() {
    focusableElements.forEach((el) => el.setAttribute("tabindex", "-1"));
  }

  function trapFocus(event) {
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    if (event.key === "Tab") {
      if (event.shiftKey && document.activeElement === firstElement) {
        event.preventDefault();
        lastElement.focus(); // Move focus to last element
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus(); // Move focus to first element
      }
    }
  }

  function openLocalizationDrawer(event) {
    if ((event.key === "Enter" || event.keyCode === 13) && localizationDrawer) {
      event.preventDefault();
      lastFocusedButton = event.target; // Store the button that triggered the drawer
      localizationDrawer.classList.add("active");
      localizationDrawer.setAttribute("aria-hidden", "false");
      document.querySelector(
        ".section-header.shopify-section-group-header-group"
      ).style.zIndex = "2";

      // Enable focus inside the drawer
      focusableElements.forEach((el) => el.setAttribute("tabindex", "0"));

      // Move focus to the first interactive element inside the drawer
      focusableElements[0]?.focus();
    }
  }

  function closeLocalizationDrawer() {
    if (localizationDrawer) {
      localizationDrawer.classList.remove("active");
      localizationDrawer.setAttribute("aria-hidden", "true");
      document.querySelector(
        ".section-header.shopify-section-group-header-group"
      ).style.zIndex = "3";

      // Disable focus inside the drawer
      disableLocalizationFocus();

      // Return focus to the button that triggered the drawer
      if (lastFocusedButton) {
        lastFocusedButton.focus();
        lastFocusedButton = null; // Reset after use
      }
    }
  }

  // Apply tabindex="-1" initially
  disableLocalizationFocus();

  // Event Listeners
  localizationButtons.forEach((button) => {
    button.addEventListener("keydown", openLocalizationDrawer);
  });

  if (closeButton) {
    closeButton.addEventListener("click", closeLocalizationDrawer);
  }

  if (localizationDrawer) {
    localizationDrawer.addEventListener("keydown", function (event) {
      if (event.key === "Escape" || event.keyCode === 27) {
        closeLocalizationDrawer();
      } else {
        trapFocus(event);
      }
    });
  }
});
