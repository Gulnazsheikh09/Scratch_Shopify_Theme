
  let subscribers = {};

function subscribe(eventName, callback) {
  if (!subscribers[eventName]) {
    subscribers[eventName] = [];
  }

  subscribers[eventName].push(callback);

  return function unsubscribe() {
    subscribers[eventName] = subscribers[eventName].filter(cb => cb !== callback);
  };
}

function publish(eventName, data) {
  subscribers[eventName]?.forEach(callback => callback(data));
}

