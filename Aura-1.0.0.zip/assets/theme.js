// Aura Theme Javascript
function findFocusableElements(container) {
  const selectors = [
    "summary",
    "a[href]",
    "button:enabled",
    "[tabindex]:not([tabindex^='-'])",
    "[draggable]",
    "area",
    "input:not([type=hidden]):enabled",
    "select:enabled",
    "textarea:enabled",
    "object",
    "iframe",
  ];

  return Array.from(container.querySelectorAll(selectors.join(", ")));
}

document.querySelectorAll('[id^="Details-"] summary').forEach((summary) => {
  summary.setAttribute("role", "button");
  summary.setAttribute(
    "aria-expanded",
    summary.parentNode.hasAttribute("open")
  );

  if (summary.nextElementSibling.getAttribute("id")) {
    summary.setAttribute("aria-controls", summary.nextElementSibling.id);
  }

  summary.addEventListener("click", (event) => {
    event.currentTarget.setAttribute(
      "aria-expanded",
      !event.currentTarget.closest("details").hasAttribute("open")
    );
  });
  summary.parentElement.addEventListener("keyup", onKeyUpEscape);
});

const trapFocusHandlers = {};

function trapFocus(container, elementToFocus = container) {
  var elements = findFocusableElements(container);
  var first = elements[0];
  var last = elements[elements.length - 1];

  //removeTrapFocus();

  trapFocusHandlers.focusin = (event) => {
    if (
      event.target !== container &&
      event.target !== last &&
      event.target !== first
    )
      return;

    document.addEventListener("keydown", trapFocusHandlers.keydown);
  };

  trapFocusHandlers.focusout = function () {
    document.removeEventListener("keydown", trapFocusHandlers.keydown);
  };

  trapFocusHandlers.keydown = function (event) {
    if (event.code.toUpperCase() !== "TAB") return; // If not TAB key
    // On the last focusable element and tab forward, focus the first element.
    if (event.target === last && !event.shiftKey) {
      event.preventDefault();
      first.focus();
    }

    //  On the first focusable element and tab backward, focus the last element.
    if (
      (event.target === container || event.target === first) &&
      event.shiftKey
    ) {
      event.preventDefault();
      last.focus();
    }
  };

  document.addEventListener("focusout", trapFocusHandlers.focusout);
  document.addEventListener("focusin", trapFocusHandlers.focusin);

  elementToFocus.focus();

  if (
    elementToFocus.tagName === "INPUT" &&
    ["search", "text", "email", "url"].includes(elementToFocus.type) &&
    elementToFocus.value
  ) {
    elementToFocus.setSelectionRange(0, elementToFocus.value.length);
  }
}

try {
  document.querySelector(":focus-visible");
} catch (e) {
  focusVisiblePolyfill();
}

function focusVisiblePolyfill() {
  const navKeys = [
    "ArrowUp",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "Tab",
    "Enter",
    "Space",
    "Escape",
    "Home",
    "End",
    "PageUp",
    "PageDown",
  ];
  let currentFocusedElement = null;
  let mouseClick = false;

  // Detect keyboard navigation
  window.addEventListener("keydown", (event) => {
    if (navKeys.includes(event.key)) {
      mouseClick = false; // Reset mouseClick on keyboard navigation
    }
  });

  // Detect mouse clicks
  window.addEventListener("mousedown", () => {
    mouseClick = true;
  });

  // Handle focus event
  window.addEventListener(
    "focus",
    () => {
      if (mouseClick) return; // Do nothing if focus was triggered by mouse click

      if (currentFocusedElement) {
        currentFocusedElement.classList.remove("focused"); // Remove the focused class from the previous element
      }

      currentFocusedElement = document.activeElement; // Get the currently focused element

      if (currentFocusedElement) {
        currentFocusedElement.classList.add("focused"); // Add the focused class to the currently focused element
      }
    },
    true // Capture phase to ensure this fires before other focus events
  );
}

function pauseAllMedia() {
  document.querySelectorAll(".js-youtube").forEach((video) => {
    video.contentWindow.postMessage(
      '{"event":"command","func":"' + "pauseVideo" + '","args":""}',
      "*"
    );
  });
  document.querySelectorAll(".js-vimeo").forEach((video) => {
    video.contentWindow.postMessage('{"method":"pause"}', "*");
  });
  document.querySelectorAll("video").forEach((video) => video.pause());
  document.querySelectorAll("product-model").forEach((model) => {
    //if (model.modelViewerUI) model.modelViewerUI.pause();
  });
}

function removeTrapFocus(elementToFocus = null) {
  document.removeEventListener("focusin", trapFocusHandlers.focusin);
  document.removeEventListener("focusout", trapFocusHandlers.focusout);
  document.removeEventListener("keydown", trapFocusHandlers.keydown);

  if (elementToFocus) elementToFocus.focus();
}

function onKeyUpEscape(event) {
  if (event.code.toUpperCase() !== "ESCAPE") return;

  const openDetailsElement = event.target.closest("details[open]");
  if (!openDetailsElement) return;

  const summaryElement = openDetailsElement.querySelector("summary");
  openDetailsElement.removeAttribute("open");
  summaryElement.setAttribute("aria-expanded", false);
  summaryElement.focus();
}

class QuantityInput extends HTMLElement {
  constructor() {
    super();
    this.input = this.querySelector("input");
    this.changeEvent = new Event("change", {
      bubbles: true,
    });
    this.input.addEventListener("change", this.onInputChange.bind(this));
    this.querySelectorAll("button").forEach((button) =>
      button.addEventListener("click", this.onButtonClick.bind(this))
    );
  }

  quantityUpdateUnsubscriber = undefined;

  connectedCallback() {
    this.validateQtyRules();
    this.quantityUpdateUnsubscriber = subscribe(
      PUB_SUB_EVENTS.quantityUpdate,
      this.validateQtyRules.bind(this)
    );
  }

  disconnectedCallback() {
    if (this.quantityUpdateUnsubscriber) {
      this.quantityUpdateUnsubscriber();
    }
  }

  onInputChange(event) {
    this.validateQtyRules();
  }

  onButtonClick(event) {
    event.preventDefault();
    const previousValue = this.input.value;

    if (event.target.name === "plus") {
      if (
        parseInt(this.input.dataset.min) > parseInt(this.input.step) &&
        this.input.value == 0
      ) {
        this.input.value = this.input.dataset.min;
      } else {
        this.input.stepUp();
      }
    } else {
      this.input.stepDown();
    }

    if (previousValue !== this.input.value)
      this.input.dispatchEvent(this.changeEvent);

    if (
      this.input.dataset.min === previousValue &&
      event.target.name === "minus"
    ) {
      this.input.value = parseInt(this.input.min);
    }
  }

  validateQtyRules() {
    const value = parseInt(this.input.value);
    if (this.input.min) {
      const buttonMinus = this.querySelector(".quantity__button[name='minus']");
      buttonMinus.classList.toggle(
        "disabled",
        parseInt(value) <= parseInt(this.input.min)
      );
    }
    if (this.input.max) {
      const max = parseInt(this.input.max);
      const buttonPlus = this.querySelector(".quantity__button[name='plus']");
      buttonPlus.classList.toggle("disabled", value >= max);
    }
  }
}

customElements.define("quantity-input", QuantityInput);

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function throttle(fn, delay) {
  let lastCall = 0;
  return function (...args) {
    const now = new Date().getTime();
    if (now - lastCall < delay) {
      return;
    }
    lastCall = now;
    return fn(...args);
  };
}

function fetchConfig(type = "json") {
  return {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: `application/${type}`,
    },
  };
}

if (typeof window.Shopify == "undefined") {
  window.Shopify = {};
}

Shopify.bind = function (fn, scope) {
  return function () {
    return fn.apply(scope, arguments);
  };
};

Shopify.setSelectorByValue = function (selector, value) {
  for (var i = 0, count = selector.options.length; i < count; i++) {
    var option = selector.options[i];
    if (value == option.value || value == option.innerHTML) {
      selector.selectedIndex = i;
      return i;
    }
  }
};

Shopify.addListener = function (target, eventName, callback) {
  target.addEventListener
    ? target.addEventListener(eventName, callback, false)
    : target.attachEvent("on" + eventName, callback);
};

Shopify.postLink = function (path, options) {
  options = options || {};
  var method = options["method"] || "post";
  var params = options["parameters"] || {};

  var form = document.createElement("form");
  form.setAttribute("method", method);
  form.setAttribute("action", path);

  for (var key in params) {
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", key);
    hiddenField.setAttribute("value", params[key]);
    form.appendChild(hiddenField);
  }
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

Shopify.CountryProvinceSelector = function (
  country_domid,
  province_domid,
  options
) {
  this.countryEl = document.getElementById(country_domid);
  this.provinceEl = document.getElementById(province_domid);
  this.provinceContainer = document.getElementById(
    options["hideElement"] || province_domid
  );

  Shopify.addListener(
    this.countryEl,
    "change",
    Shopify.bind(this.countryHandler, this)
  );

  this.initCountry();
  this.initProvince();
};

Shopify.CountryProvinceSelector.prototype = {
  initCountry: function () {
    var value = this.countryEl.getAttribute("data-default");
    Shopify.setSelectorByValue(this.countryEl, value);
    this.countryHandler();
  },

  initProvince: function () {
    var value = this.provinceEl.getAttribute("data-default");
    if (value && this.provinceEl.options.length > 0) {
      Shopify.setSelectorByValue(this.provinceEl, value);
    }
  },

  countryHandler: function (e) {
    var opt = this.countryEl.options[this.countryEl.selectedIndex];
    var raw = opt.getAttribute("data-provinces");
    var provinces = JSON.parse(raw);

    this.clearOptions(this.provinceEl);
    if (provinces && provinces.length == 0) {
      this.provinceContainer.style.display = "none";
    } else {
      for (var i = 0; i < provinces.length; i++) {
        var opt = document.createElement("option");
        opt.value = provinces[i][0];
        opt.innerHTML = provinces[i][1];
        this.provinceEl.appendChild(opt);
      }

      this.provinceContainer.style.display = "";
    }
  },

  clearOptions: function (selector) {
    while (selector.firstChild) {
      selector.removeChild(selector.firstChild);
    }
  },

  setOptions: function (selector, values) {
    for (var i = 0, count = values.length; i < values.length; i++) {
      var opt = document.createElement("option");
      opt.value = values[i];
      opt.innerHTML = values[i];
      selector.appendChild(opt);
    }
  },
};

class ModalDialog extends HTMLElement {
  constructor() {
    super();
    this.querySelector('[id^="ModalClose-"]').addEventListener(
      "click",
      this.hide.bind(this, false)
    );
    this.addEventListener("keyup", (event) => {
      if (event.code.toUpperCase() === "ESCAPE") this.hide();
    });
    if (this.classList.contains("media-modal")) {
      this.addEventListener("pointerup", (event) => {
        if (
          event.pointerType === "mouse" &&
          !event.target.closest("deferred-media, product-model")
        )
          this.hide();
      });
    } else {
      this.addEventListener("click", (event) => {
        if (event.target === this) this.hide();
      });
    }
  }

  connectedCallback() {
    if (this.moved) return;
    this.moved = true;
    document.body.appendChild(this);
  }

  show(opener) {
    this.openedBy = opener;
    const popup = this.querySelector(".template-popup");
    document.body.classList.add("overflow-hidden");
    this.setAttribute("open", "");
    if (popup) popup.loadContent();
    trapFocus(this, this.querySelector('[role="dialog"]'));
    console.log(this);
    console.log(this.querySelector('[role="dialog"]'));
    window.pauseAllMedia();
  }

  hide() {
    document.body.classList.remove("overflow-hidden");
    document.body.dispatchEvent(new CustomEvent("modalClosed"));
    this.removeAttribute("open");
    removeTrapFocus(this.openedBy);
    window.pauseAllMedia();
  }
}
customElements.define("modal-dialog", ModalDialog);

class ModalOpener extends HTMLElement {
  constructor() {
    super();

    const button = this.querySelector("button");

    if (!button) return;
    button.addEventListener("click", () => {
      const modal = document.querySelector(this.getAttribute("data-modal"));
      if (modal) modal.show(button);
    });
  }
}
customElements.define("modal-opener", ModalOpener);

// Product page DeferredMedia Model

class DeferredMedia extends HTMLElement {
  constructor() {
    super();
    const poster = this.querySelector('[id^="Deferred-Poster-"]');
    if (!poster) return;
    poster.addEventListener("click", this.loadContent.bind(this));
  }

  loadContent(focus = true) {
    window.pauseAllMedia();
    if (!this.getAttribute("loaded")) {
      const content = document.createElement("div");
      content.appendChild(
        this.querySelector("template").content.firstElementChild.cloneNode(true)
      );

      this.setAttribute("loaded", true);
      const deferredElement = this.appendChild(
        content.querySelector("video, model-viewer, iframe")
      );
      if (focus) deferredElement.focus();
      if (
        deferredElement.nodeName == "VIDEO" &&
        deferredElement.getAttribute("autoplay")
      ) {
        // force autoplay for safari
        deferredElement.play();
      }
    }
  }
}

customElements.define("deferred-media", DeferredMedia);

// Product Page Slider Code

class CarouselComponent extends HTMLElement {
  constructor() {
    super();
    this.slider = this.querySelector('[id^="Slider-"]');
    this.sliderItems = this.querySelectorAll('[id^="Slide-"]');
    this.enableSliderLooping = false;
    this.currentPageElement = this.querySelector(".slider-counter--current");
    this.pageTotalElement = this.querySelector(".slider-counter--total");
    this.prevButton = this.querySelector('button[name="previous"]');
    this.nextButton = this.querySelector('button[name="next"]');

    if (!this.slider || !this.nextButton) return;

    this.initPages();
    const resizeObserver = new ResizeObserver((entries) => this.initPages());
    resizeObserver.observe(this.slider);

    this.slider.addEventListener("scroll", this.update.bind(this));
    this.prevButton.addEventListener("click", this.onButtonClick.bind(this));
    this.nextButton.addEventListener("click", this.onButtonClick.bind(this));
  }

  initPages() {
    this.sliderItemsToShow = Array.from(this.sliderItems).filter(
      (element) => element.clientWidth > 0
    );
    if (this.sliderItemsToShow.length < 2) return;
    this.sliderItemOffset =
      this.sliderItemsToShow[1].offsetLeft -
      this.sliderItemsToShow[0].offsetLeft;
    this.slidesPerPage = Math.floor(
      (this.slider.clientWidth - this.sliderItemsToShow[0].offsetLeft) /
        this.sliderItemOffset
    );
    this.totalPages = this.sliderItemsToShow.length - this.slidesPerPage + 1;
    this.update();
  }

  resetPages() {
    // Select all slider items with id starting with "Slide-"
    this.sliderItems = this.querySelectorAll('[id^="Slide-"]');

    // Check if any slider items are found
    if (this.sliderItems.length === 0) {
      console.warn('No slider items found with ids starting with "Slide-"');
      return; // Early exit if no items are found
    }

    // Optional: Clear any previous state if needed
    this.clearSliderState(); // This would be an additional method you might need to create

    // Initialize pages (pagination, slider, etc.)
    this.initPages();
  }

  update() {
    if (!this.slider || !this.nextButton) return;

    const previousPage = this.currentPage;
    this.currentPage =
      Math.round(this.slider.scrollLeft / this.sliderItemOffset) + 1;

    if (this.currentPageElement && this.pageTotalElement) {
      this.currentPageElement.textContent = this.currentPage;
      this.pageTotalElement.textContent = this.totalPages;
    }

    if (this.currentPage != previousPage) {
      this.dispatchEvent(
        new CustomEvent("slideChanged", {
          detail: {
            currentPage: this.currentPage,
            currentElement: this.sliderItemsToShow[this.currentPage - 1],
          },
        })
      );
    }

    if (this.enableSliderLooping) return;

    if (
      this.isSlideVisible(this.sliderItemsToShow[0]) &&
      this.slider.scrollLeft === 0
    ) {
      this.prevButton.setAttribute("disabled", "disabled");
    } else {
      this.prevButton.removeAttribute("disabled");
    }

    if (
      this.isSlideVisible(
        this.sliderItemsToShow[this.sliderItemsToShow.length - 1]
      )
    ) {
      this.nextButton.setAttribute("disabled", "disabled");
    } else {
      this.nextButton.removeAttribute("disabled");
    }
  }

  isSlideVisible(element, offset = 0) {
    const lastVisibleSlide =
      this.slider.clientWidth + this.slider.scrollLeft - offset;
    return (
      element.offsetLeft + element.clientWidth <= lastVisibleSlide &&
      element.offsetLeft >= this.slider.scrollLeft
    );
  }

  onButtonClick(event) {
    event.preventDefault();
    const step = event.currentTarget.dataset.step || 1;
    this.slideScrollPosition =
      event.currentTarget.name === "next"
        ? this.slider.scrollLeft + step * this.sliderItemOffset
        : this.slider.scrollLeft - step * this.sliderItemOffset;
    this.setSlidePosition(this.slideScrollPosition);
  }

  setSlidePosition(position) {
    this.slider.scrollTo({
      left: position,
    });
  }
}

customElements.define("slider-component", CarouselComponent);

// VariantOptions Code

class VariantOptions extends HTMLElement {
  constructor() {
    super();
    this.addEventListener("change", this.onVariantChange);
  }

  onVariantChange(event) {
    this.changeOptions();
    this.updatePrimaryId();
    this.updateSelectedSwatchValue(event);
    this.toggleAddButton(true, "", false);
    this.refreshPickupAvailability();
    this.removeErrorMessage();
    this.refreshVariantStatuses();

    if (!this.activeVariant) {
      this.toggleAddButton(true, "", true);
      this.setUnavailable();
    } else {
      this.refreshURL();
      this.updateVariantInput();
      this.renderProductObject();
      this.updateMeta();
      this.updateSticky();
    }
  }

  updateMeta() {
    const currentVariantIds = this.activeVariant.id;
    const event = new CustomEvent("variantChanged", {
      detail: {
        currentVariantIds: currentVariantIds,
      },
    });
    window.dispatchEvent(event);
  }

  updateSticky() {
    const currentVariantTitle = this.activeVariant.title;

    const content = {
      product_variant: currentVariantTitle,
    };
    const sInfoProduct = document.querySelector(".procut_vartiant");
    if (sInfoProduct) {
      sInfoProduct.dataset.productVariant = content.product_variant;
      sInfoProduct.textContent = content.product_variant;
    } else {
      console.warn("Element not found. Unable to update product variant.");
    }
  }

  changeOptions() {
    this.options = Array.from(
      this.querySelectorAll("select, fieldset"),
      (element) => {
        if (element.tagName === "SELECT") {
          return element.value;
        }
        if (element.tagName === "FIELDSET") {
          return Array.from(element.querySelectorAll("input")).find(
            (radio) => radio.checked
          )?.value;
        }
      }
    );
  }

  updatePrimaryId() {
    this.activeVariant = this.getVariantData().find((variant) => {
      return !variant.options
        .map((option, index) => {
          return this.options[index] === option;
        })
        .includes(false);
    });
  }

  updateSelectedSwatchValue({ target }) {
    const { name, value, tagName } = target;

    if (tagName === "SELECT" && target.selectedOptions.length) {
      const swatchValue = target.selectedOptions[0].dataset.optionSwatchValue;
      const selectedDropdownSwatchValue = this.querySelector(
        `[data-selected-dropdown-swatch="${name}"] > .swatch`
      );
      if (!selectedDropdownSwatchValue) return;
      if (swatchValue) {
        selectedDropdownSwatchValue.style.setProperty(
          "--swatch--background",
          swatchValue
        );
        selectedDropdownSwatchValue.classList.remove("swatch--unavailable");
      } else {
        selectedDropdownSwatchValue.style.setProperty(
          "--swatch--background",
          "unset"
        );
        selectedDropdownSwatchValue.classList.add("swatch--unavailable");
      }

      selectedDropdownSwatchValue.style.setProperty(
        "--swatch-focal-point",
        target.selectedOptions[0].dataset.optionSwatchFocalPoint || "unset"
      );
    } else if (tagName === "INPUT" && target.type === "radio") {
      const selectedSwatchValue = this.querySelector(
        `[data-selected-swatch-value="${name}"]`
      );
      if (selectedSwatchValue) selectedSwatchValue.innerHTML = value;
    }
  }

  refreshURL() {
    if (!this.activeVariant || this.dataset.updateUrl === "false") return;
    window.history.replaceState(
      {},
      "",
      `${this.dataset.url}?variant=${this.activeVariant.id}`
    );
  }

  updateVariantInput() {
    const productForms = document.querySelectorAll(
      `#product-form-${this.dataset.section}, #product-form-installment-${this.dataset.section}`
    );
    productForms.forEach((productForm) => {
      const input = productForm.querySelector('input[name="id"]');
      input.value = this.activeVariant.id;
      input.dispatchEvent(
        new Event("change", {
          bubbles: true,
        })
      );
    });
  }

  refreshVariantStatuses() {
    const selectedOptionOneVariants = this.variantData.filter(
      (variant) => this.querySelector(":checked").value === variant.option1
    );
    const inputWrappers = [...this.querySelectorAll(".product-input-field")];
    inputWrappers.forEach((option, index) => {
      if (index === 0) return;
      const optionInputs = [
        ...option.querySelectorAll('input[type="radio"], option'),
      ];
      const previousOptionSelected =
        inputWrappers[index - 1].querySelector(":checked").value;
      const availableOptionInputsValue = selectedOptionOneVariants
        .filter(
          (variant) =>
            variant.available &&
            variant[`option${index}`] === previousOptionSelected
        )
        .map((variantOption) => variantOption[`option${index + 1}`]);
      this.setInputAvailability(optionInputs, availableOptionInputsValue);
    });
  }

  setInputAvailability(elementList, availableValuesList) {
    elementList.forEach((element) => {
      const value = element.getAttribute("value");
      const availableElement = availableValuesList.includes(value);

      if (element.tagName === "INPUT") {
        element.classList.toggle("disabled", !availableElement);
      } else if (element.tagName === "OPTION") {
        element.innerText = availableElement
          ? value
          : window.variantStrings.unavailable_with_option.replace(
              "[value]",
              value
            );
      }
    });
  }

  refreshPickupAvailability() {
    const PickupAvailable = document.querySelector("pickup-available");
    if (!PickupAvailable) return;

    if (this.activeVariant && this.activeVariant.available) {
      PickupAvailable.fetchAvailability_product(this.activeVariant.id);
    } else {
      PickupAvailable.removeAttribute("available");
      PickupAvailable.innerHTML = "";
    }
  }

  removeErrorMessage() {
    const section = this.closest("section");
    if (!section) return;

    const productForm = section.querySelector("product-form");
    if (productForm) productForm.handleError();
  }

  updateMedia(html) {
    const mediaGallerySource = document.querySelector(
      `[id^="MediaGallery-${this.dataset.section}"] ul`
    );
    const mediaGalleryDestination = html.querySelector(
      `[id^="MediaGallery-${this.dataset.section}"] ul`
    );

    const refreshSourceData = () => {
      const mediaGallerySourceItems = Array.from(
        mediaGallerySource.querySelectorAll("li[data-media-id]")
      );
      const sourceSet = new Set(
        mediaGallerySourceItems.map((item) => item.dataset.mediaId)
      );
      const sourceMap = new Map(
        mediaGallerySourceItems.map((item, index) => [
          item.dataset.mediaId,
          {
            item,
            index,
          },
        ])
      );
      return [mediaGallerySourceItems, sourceSet, sourceMap];
    };

    if (mediaGallerySource && mediaGalleryDestination) {
      let [mediaGallerySourceItems, sourceSet, sourceMap] = refreshSourceData();
      const mediaGalleryDestinationItems = Array.from(
        mediaGalleryDestination.querySelectorAll("li[data-media-id]")
      );
      const destinationSet = new Set(
        mediaGalleryDestinationItems.map(({ dataset }) => dataset.mediaId)
      );
      let shouldRefresh = false;

      // add items from new data not present in DOM
      for (let i = mediaGalleryDestinationItems.length - 1; i >= 0; i--) {
        if (!sourceSet.has(mediaGalleryDestinationItems[i].dataset.mediaId)) {
          mediaGallerySource.prepend(mediaGalleryDestinationItems[i]);
          shouldRefresh = true;
        }
      }

      // remove items from DOM not present in new data
      for (let i = 0; i < mediaGallerySourceItems.length; i++) {
        if (!destinationSet.has(mediaGallerySourceItems[i].dataset.mediaId)) {
          mediaGallerySourceItems[i].remove();
          shouldRefresh = true;
        }
      }

      // refresh
      if (shouldRefresh)
        [mediaGallerySourceItems, sourceSet, sourceMap] = refreshSourceData();

      // if media galleries don't match, sort to match new data order
      mediaGalleryDestinationItems.forEach(
        (destinationItem, destinationIndex) => {
          const sourceData = sourceMap.get(destinationItem.dataset.mediaId);

          if (sourceData && sourceData.index !== destinationIndex) {
            mediaGallerySource.insertBefore(
              sourceData.item,
              mediaGallerySource.querySelector(
                `li:nth-of-type(${destinationIndex + 1})`
              )
            );

            // refresh source now that it has been modified
            [mediaGallerySourceItems, sourceSet, sourceMap] =
              refreshSourceData();
          }
        }
      );
    }

    if (this.activeVariant.featured_media) {
      document
        .querySelector(`[id^="MediaGallery-${this.dataset.section}"]`)
        ?.setActiveMedia?.(
          `${this.dataset.section}-${this.activeVariant.featured_media.id}`
        );
    }
  }

  renderProductObject() {
    const requestedVariantId = this.activeVariant.id;
    const sectionId = this.dataset.originalSection
      ? this.dataset.originalSection
      : this.dataset.section;

    fetch(
      `${this.dataset.url}?variant=${requestedVariantId}&section_id=${
        this.dataset.originalSection
          ? this.dataset.originalSection
          : this.dataset.section
      }`
    )
      .then((response) => response.text())
      .then((responseText) => {
        // prevent unnecessary ui changes from abandoned selections
        if (this.activeVariant.id !== requestedVariantId) return;

        const html = new DOMParser().parseFromString(responseText, "text/html");
        const destination = document.getElementById(
          `price-${this.dataset.section}`
        );
        const source = html.getElementById(
          `price-${
            this.dataset.originalSection
              ? this.dataset.originalSection
              : this.dataset.section
          }`
        );
        const skuSource = html.getElementById(
          `Sku-${
            this.dataset.originalSection
              ? this.dataset.originalSection
              : this.dataset.section
          }`
        );
        const skuDestination = document.getElementById(
          `Sku-${this.dataset.section}`
        );
        const inventorySource = html.getElementById(
          `Inventory-${
            this.dataset.originalSection
              ? this.dataset.originalSection
              : this.dataset.section
          }`
        );
        const inventoryDestination = document.getElementById(
          `Inventory-${this.dataset.section}`
        );

        const volumePricingSource = html.getElementById(
          `Volume-${
            this.dataset.originalSection
              ? this.dataset.originalSection
              : this.dataset.section
          }`
        );

        this.updateMedia(html);

        const pricePerItemDestination = document.getElementById(
          `Price-Per-Item-${this.dataset.section}`
        );
        const pricePerItemSource = html.getElementById(
          `Price-Per-Item-${
            this.dataset.originalSection
              ? this.dataset.originalSection
              : this.dataset.section
          }`
        );

        const volumePricingDestination = document.getElementById(
          `Volume-${this.dataset.section}`
        );
        const qtyRules = document.getElementById(
          `Quantity-Rules-${this.dataset.section}`
        );
        const volumeNote = document.getElementById(
          `Volume-Note-${this.dataset.section}`
        );

        if (volumeNote) volumeNote.classList.remove("hidden");
        if (volumePricingDestination)
          volumePricingDestination.classList.remove("hidden");
        if (qtyRules) qtyRules.classList.remove("hidden");

        if (source && destination) destination.innerHTML = source.innerHTML;
        if (inventorySource && inventoryDestination)
          inventoryDestination.innerHTML = inventorySource.innerHTML;
        if (skuSource && skuDestination) {
          skuDestination.innerHTML = skuSource.innerHTML;
          skuDestination.classList.toggle(
            "hidden",
            skuSource.classList.contains("hidden")
          );
        }

        if (volumePricingSource && volumePricingDestination) {
          volumePricingDestination.innerHTML = volumePricingSource.innerHTML;
        }

        if (pricePerItemSource && pricePerItemDestination) {
          pricePerItemDestination.innerHTML = pricePerItemSource.innerHTML;
          pricePerItemDestination.classList.toggle(
            "hidden",
            pricePerItemSource.classList.contains("hidden")
          );
        }

        const price = document.getElementById(`price-${this.dataset.section}`);

        if (price) price.classList.remove("hidden");

        if (inventoryDestination)
          inventoryDestination.classList.toggle(
            "hidden",
            inventorySource.innerText === ""
          );

        const addButtonUpdated = html.getElementById(
          `ProductSubmitButton-${sectionId}`
        );
        this.toggleAddButton(
          addButtonUpdated ? addButtonUpdated.hasAttribute("disabled") : true,
          window.variantStrings.soldOut
        );

        publish(PUB_SUB_EVENTS.variantChange, {
          data: {
            sectionId,
            html,
            variant: this.activeVariant,
          },
        });
      });
  }

  toggleAddButton(disable = true, text, modifyClass = true) {
    const productForm = document.getElementById(
      `product-form-${this.dataset.section}`
    );
    if (!productForm) return;
    const addButton = productForm.querySelector('[name="add"]');
    const addButtonText = productForm.querySelector('[name="add"] > codes');
    if (!addButton) return;

    if (disable) {
      addButton.setAttribute("disabled", "disabled");
      if (text) addButtonText.textContent = text;
    } else {
      addButton.removeAttribute("disabled");
      addButtonText.textContent = window.variantStrings.addToCart;
    }

    if (!modifyClass) return;
  }

  setUnavailable() {
    const button = document.getElementById(
      `product-form-${this.dataset.section}`
    );
    const addButton = button.querySelector('[name="add"]');
    const addButtonText = button.querySelector('[name="add"] > codes');
    const price = document.getElementById(`price-${this.dataset.section}`);
    const inventory = document.getElementById(
      `Inventory-${this.dataset.section}`
    );
    const inventorys = document.getElementById(
      `Checkoutdiscount-${this.dataset.section}`
    );
    const sku = document.getElementById(`Sku-${this.dataset.section}`);

    if (!addButton) return;
    addButtonText.textContent = window.variantStrings.unavailable;
    if (price) price.classList.add("hidden");
    if (inventory) inventory.classList.add("hidden");
    if (inventorys) inventory.classList.add("hidden");
    if (sku) sku.classList.add("hidden");
    if (pricePerItem) pricePerItem.classList.add("hidden");
  }

  getVariantData() {
    this.variantData =
      this.variantData ||
      JSON.parse(this.querySelector('[type="application/json"]').textContent);
    return this.variantData;
  }
}

customElements.define("variant-picker", VariantOptions);

// BUTTON HOVER EFFECT
document.addEventListener("DOMContentLoaded", function () {
  const btns = document.querySelectorAll(".btn");

  btns.forEach(function (btn) {
    btn.addEventListener("mouseenter", function (e) {
      const parentOffset = btn.getBoundingClientRect();
      const relX = e.clientX - parentOffset.left;
      const relY = e.clientY - parentOffset.top;

      const span = btn.querySelector("span");
      span.style.top = `${relY}px`;
      span.style.left = `${relX}px`;
    });

    btn.addEventListener("mouseout", function (e) {
      const parentOffset = btn.getBoundingClientRect();
      const relX = e.clientX - parentOffset.left;
      const relY = e.clientY - parentOffset.top;
      const span = btn.querySelector("span");
      span.style.top = `${relY}px`;
      span.style.left = `${relX}px`;
    });
  });
});

// Related Products
class RelatedProducts extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    const observer = new IntersectionObserver(
      (entries, observer) => {
        if (entries[0].isIntersecting) {
          observer.unobserve(this);

          fetch(this.dataset.url)
            .then((response) => response.text())
            .then((text) => {
              const tempDiv = document.createElement("div");
              tempDiv.innerHTML = text;

              const recommendations = tempDiv.querySelector(
                "product-recommendations"
              );
              if (recommendations) {
                this.innerHTML = recommendations.innerHTML.trim();
                if (recommendations.querySelector(".grid__item")) {
                  this.classList.add("product-recommendations--loaded");
                  var swiper = new Swiper(
                    ".product-recommendations--loaded .pr",
                    {
                      pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                      },
                      slidesPerView: 4,
                      spaceBetween: 30,
                      breakpoints: {
                        0: {
                          slidesPerView: 2,
                          spaceBetween: 15,
                        },
                        768: {
                          slidesPerView: 3,
                          spaceBetween: 30,
                        },
                        1150: {
                          slidesPerView: 4,
                          spaceBetween: 30,
                        },
                      },
                    }
                  );

                  // var swiper1 = new Swiper(
                  //   ".product-recommendations--loaded .cbl",
                  //   {
                  //     slidesPerView: 2,
                  //     spaceBetween: 30,
                  //   }
                  // );
                }
              }
            })
            .catch(console.error);
        }
      },
      { rootMargin: "0px 0px 400px 0px" }
    );

    observer.observe(this);
  }
}

customElements.define("product-recommendations", RelatedProducts);

//STICKY VIDEO EXPAND
class StickyScroll extends HTMLElement {
  constructor() {
    super(),
      !(this.hasAttribute("data-mobile-disabled") && isMobileScreen()) &&
        ((this.hasListenWindowScroll = !1),
        (this.inView = !1),
        (this.preStatus = 0),
        (this.currentStatus = 0),
        (this.stickyContainer = this.querySelector(".sticky_scroll_container")),
        this.stickyContainer &&
          ((this.changeRatio = 0),
          (this.stickyScrollDistance =
            parseInt(this.getAttribute("data-sticky-distance")) || 0),
          this.getTriggerOffset(),
          (this.topHalt = parseInt(this.getAttribute("data-top-halt")) || 0),
          (this.bottomHalt =
            parseInt(this.getAttribute("data-bottom-halt")) || 0),
          !(
            this.stickyScrollDistance > 0 &&
            this.stickyScrollDistance - this.topHalt - this.bottomHalt <= 0
          ) &&
            ((this.containerHeight = this.offsetHeight),
            (this.boundHandleScrollEffect = this.handleScrollEffect.bind(this)),
            this.hasAttribute("data-initialized") || this.initializeHeight(),
            this.observeScrollIntoView())));
  }
  disconnectedCallback() {
    this.observer && this.observer.disconnect();
  }
  observeScrollIntoView() {
    (this.observer = new IntersectionObserver(
      (entries) => {
        (this.inView = entries[0].isIntersecting),
          this.inView &&
            this.hasAttribute("data-initialized") &&
            this.referencePageScrollY == null &&
            this.getReferenceScrollY(),
          this.inView
            ? this.listenWindowScroll()
            : this.removeListenWindowScroll();
      },
      {
        root: null,
        rootMargin: "0px 0px -200px 0px",
        threshold: 0,
      }
    )),
      this.observer.observe(this);
  }
  getTriggerOffset() {
    this.triggerPosition = this.getAttribute("data-trigger-position") || "top";
    const clientHeight = document.documentElement.clientHeight;
    this.triggerPosition === "top"
      ? (this.triggerOffset = 0)
      : this.triggerPosition === "center"
      ? (this.triggerOffset = clientHeight / 2)
      : (this.triggerOffset = clientHeight);
  }
  getReferenceScrollY() {
    const rect = this.getBoundingClientRect(),
      pageScrollTop = window.scrollY || document.documentElement.scrollTop;
    this.referencePageScrollY = pageScrollTop + rect.top - this.triggerOffset;
  }
  listenWindowScroll() {
    this.hasListenWindowScroll ||
      (window.addEventListener("scroll", this.boundHandleScrollEffect),
      (this.hasListenWindowScroll = !0));
  }
  removeListenWindowScroll() {
    this.hasListenWindowScroll &&
      (window.removeEventListener("scroll", this.boundHandleScrollEffect),
      (this.hasListenWindowScroll = !1));
  }
  initializeHeight() {
    (this.style.height = `${
      this.containerHeight + this.stickyScrollDistance
    }px`),
      this.setAttribute("data-initialized", "true");
  }
  handleScrollEffect() {
    const currentPageScrollY =
        window.scrollY || document.documentElement.scrollTop,
      rect = this.getBoundingClientRect();
    if (
      rect.top <= this.triggerOffset &&
      rect.bottom > document.documentElement.clientHeight
    ) {
      const ratio =
        (currentPageScrollY - this.referencePageScrollY - this.topHalt) /
        (this.stickyScrollDistance +
          this.triggerOffset -
          this.topHalt -
          this.bottomHalt);
      this.changeRatio = Math.min(1, Math.max(0, ratio));
    } else
      rect.top > this.triggerOffset
        ? (this.changeRatio = 0)
        : (this.changeRatio = 1);
    this.changeRatio <= 0
      ? (this.currentStatus = 0)
      : this.changeRatio >= 1
      ? (this.currentStatus = 2)
      : (this.currentStatus = 1),
      this.preStatus !== this.currentStatus &&
        (this.currentStatus === 1
          ? (this.classList.add("sticky_scroll--effect"),
            this.classList.remove("sticky_scroll--end"))
          : this.currentStatus === 2
          ? (this.classList.add("sticky_scroll--end"),
            this.classList.remove("sticky_scroll--effect"))
          : (this.classList.remove("sticky_scroll--effect"),
            this.classList.remove("sticky_scroll--end"))),
      (this.preStatus = this.currentStatus),
      this.style.setProperty("--change-ratio", this.changeRatio);
  }
}
customElements.define("sticky-video-expand", StickyScroll);

function isMobile() {
  return window.matchMedia("(max-width: 749px)").matches;
}

document.addEventListener("DOMContentLoaded", function () {
  initializeScroll();
});

function initializeScroll() {
  if (
    window.matchMedia("(prefers-reduced-motion: reduce)").matches ||
    isMobile()
  )
    return;
  const animationTriggerElements = Array.from(
    document.querySelectorAll(
      ".scroll-synergy:not([data-scroll-synergy-observed])"
    )
  );
  if (animationTriggerElements.length === 0) return;
  const observer = new IntersectionObserver((elements) => {
    elements.forEach((entry) => {
      let prePosition;
      const handleScroll = throttle(() => {
        const percentage = percentageSeen(entry.target);
        let position = 0;
        if (
          (percentage <= 0
            ? (position = 0)
            : percentage < 30
            ? (position = 1)
            : percentage < 100
            ? (position = 2)
            : (position = 3),
          prePosition !== position &&
            (entry.target.classList.remove(
              "synergy-position--1",
              "synergy-position--2"
            ),
            position > 0 &&
              position < 3 &&
              entry.target.classList.add(`synergy-position--${position}`),
            (prePosition = position)),
          entry.target.style.setProperty("--synergy-ratio", `${percentage}%`),
          entry.target.classList.contains("synergy--zoom-in"))
        ) {
          const zoomInRatio = 1 + 0.005 * percentage;
          entry.target.style.setProperty(
            "--zoom-in-ratio",
            zoomInRatio.toString()
          );
        } else if (entry.target.classList.contains("synergy--parallax")) {
          const parallaxRatio = percentage / 100;
          entry.target.style.setProperty(
            "--parallax-ratio",
            parallaxRatio.toString()
          );
        } else if (
          entry.target.classList.contains("synergy--crab-left") ||
          entry.target.classList.contains("synergy--crab-right")
        ) {
          let crabRatio = 0.25 * percentage;
          entry.target.classList.contains("synergy--crab-left") &&
            (crabRatio = -1 * crabRatio),
            entry.target.style.setProperty("--crab-ratio", `${crabRatio}%`);
        }
      });
      entry.isIntersecting
        ? window.addEventListener("scroll", handleScroll)
        : window.removeEventListener("scroll", handleScroll);
    });
  });
  animationTriggerElements.forEach((element) => {
    observer.observe(element),
      element.setAttribute("data-scroll-synergy-observed", "true");
  });
}
//STICKY VIDEO EXPAND END

// STICKY SCROLL
customElements.get("scroll-seamless") ||
  customElements.define(
    "scroll-seamless",
    class extends HTMLElement {
      constructor() {
        super(),
          (this.listContainer = this.querySelector(".scroll-list")),
          (this.scrollDirection =
            this.getAttribute("data-direction") || "left"),
          (this.speed = parseInt(this.getAttribute("data-speed")) || 40),
          (this.currentTrans = 0),
          (this.lastWindowWidth = window.innerWidth),
          this.observeInView(),
          (window.Shopify.designMode || window.debug) &&
            ((this.debounceWindowSizeChangeHandler = debounce(
              this.onWindowSizeChange.bind(this),
              500
            )),
            window.addEventListener(
              "resize",
              this.debounceWindowSizeChangeHandler
            ));
      }
      disconnectedCallback() {
        this.debounceWindowSizeChangeHandler &&
          window.removeEventListener(
            "resize",
            this.debounceWindowSizeChangeHandler
          );
      }
      init() {
        if ((this.getAllItems(), this.items.length < 1)) return;
        this.getOriginalTotalWidth(),
          this.cloneItems(),
          this.getAllItems(),
          this.getGap();
        console.log(this.getGap());
        const transformDistance = this.originalWidth + this.gap;
        this.scrollDirection === "left"
          ? (this.style.setProperty("--from-x", "0"),
            this.style.setProperty("--end-x", `-${transformDistance}px`))
          : (this.style.setProperty(
              "--from-x",
              `${this.clientWidth - this.scrollWidth}px`
            ),
            this.style.setProperty(
              "--end-x",
              `${this.clientWidth - this.scrollWidth + transformDistance}px`
            )),
          this.style.setProperty(
            "--scroll-speed",
            `${transformDistance / this.speed}s`
          ),
          this.setAttribute("data-init", "true");
      }
      onWindowSizeChange() {
        const currentWidth = window.innerWidth;
        currentWidth !== this.lastWindowWidth &&
          ((this.lastWindowWidth = currentWidth),
          this.hasAttribute("data-init") &&
            (this.removeAttribute("data-init"),
            setTimeout(() => {
              this.classList.add("hidden"),
                this.querySelectorAll(".item-clone").forEach((item) =>
                  item.remove()
                ),
                this.classList.remove("hidden"),
                this.init();
            })));
      }
      observeInView() {
        new IntersectionObserver(
          (entries, observer2) => {
            entries[0].isIntersecting && (this.init(), observer2.disconnect());
          },
          {
            root: null,
            rootMargin: "100px 0px 100px 0px",
          }
        ).observe(this);
      }
      cloneItems() {
        const times = Math.ceil(this.clientWidth / this.originalWidth);
        let fragment = document.createDocumentFragment();
        for (let i = 0; i < times; i++)
          this.items.forEach((item) => {
            const cloneItem = item.cloneNode(!0);
            cloneItem.removeAttribute("data-shopify-editor-block"),
              cloneItem.classList.add("item-clone"),
              fragment.appendChild(cloneItem);
          });
        this.listContainer.appendChild(fragment);
      }
      getAllItems() {
        this.items = Array.from(this.querySelectorAll(".scroll-item"));
      }
      getOriginalTotalWidth() {
        this.originalWidth =
          this.items[this.items.length - 1].offsetLeft -
          this.items[0].offsetLeft +
          this.items[this.items.length - 1].offsetWidth;
      }
      getGap() {
        this.items.length < 2
          ? (this.gap = 32)
          : (this.gap =
              this.items[1].offsetLeft -
              this.items[0].offsetLeft -
              this.items[0].offsetWidth);
      }
      moveItemVisible(item) {
        if (this.items.indexOf(item) === -1) return;
        const containerRect = this.getBoundingClientRect(),
          itemRect = item.getBoundingClientRect();
        let offset;
        if (itemRect.right > containerRect.right)
          offset = containerRect.right - itemRect.right;
        else if (itemRect.left < containerRect.left)
          offset = containerRect.left - itemRect.left;
        else return;
        (this.currentTrans = this.currentTrans + offset),
          (this.listContainer.style.transform = `translateX(${this.currentTrans}px)`);
      }
    }
  );

// STICKY SCROLL END

// SINGLE Product Slider
document.addEventListener("DOMContentLoaded", function () {
  var swiper = new Swiper(".swiper-container_single", {
    slidesPerView: 1,
    grid: {
      rows: 1,
      fill: "row",
    },
    spaceBetween: 10,
    navigation: {
      nextEl: ".swiper-button-next_single",
      prevEl: ".swiper-button-prev_single",
    },
    breakpoints: {
      500: {
        slidesPerView: 1,
        spaceBetween: 15,
        freeMode: false,
        speed: 800,
      },
      990: {
        slidesPerView: 1,
        spaceBetween: 15,
      },
      1250: {
        slidesPerView: 2,
        spaceBetween: 10,
      },
    },
  });
});
// SINGLE Product Slider End

// FAQ SECTION JS
const faqHeaders = document.querySelectorAll(".faq-toggle button");

faqHeaders.forEach((header) => {
  header.addEventListener("click", () => {
    const parent = header.parentElement;

    document.querySelectorAll(".faq-toggle").forEach((item) => {
      if (item !== parent) {
        item.classList.remove("active");
      }
    });

    const content = parent.querySelector(".faq_content_toggle");
    parent.classList.toggle("active");
  });
});
// FAQ SECTION JS

// BACK TO TOP
const scrollTop = document.querySelector(".scrollTop");
if (scrollTop) {
  const scrollTopInner = scrollTop.querySelector(".scrolltop__inner");
  const path = scrollTop.querySelector("svg path");
  window.onscroll = function () {
    if (
      document.body.scrollTop > 100 ||
      document.documentElement.scrollTop > 100
    ) {
      scrollTop.style.transform = "translateY(0)";
      scrollTop.style.opacity = "1";
      scrollTop.style.height = "10rem";
    } else {
      scrollTop.style.transform = "translateY(200%)";
      scrollTop.style.opacity = "0";
      scrollTop.style.height = "5rem";
    }
  };

  function scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  scrollTop.addEventListener("click", scrollToTop);

  // Function to calculate the scroll percentage
  function calculateScrollPercentage() {
    // Get the total scrollable height
    var scrollableHeight =
      document.documentElement.scrollHeight - window.innerHeight;

    // Get the current scroll position
    var scrollPosition = window.scrollY;

    // Calculate the percentage of the page scrolled
    var scrollPercentage = (scrollPosition / scrollableHeight) * 100;
    var cp = scrollPosition / scrollableHeight;
    path.style.filter = `invert(${cp})`;

    // Display the percentage on the page
    var per = Math.round(scrollPercentage) + "%";
    scrollTopInner.style.transform = `scale(1, ${per})`;
  }

  // Add the scroll event listener
  window.addEventListener("scroll", calculateScrollPercentage);
}

// BACK TO TOP End
