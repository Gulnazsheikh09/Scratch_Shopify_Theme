if (!customElements.get('product-form')) {
  customElements.define(
    'product-form',
    class addToCartForm extends HTMLElement {
      constructor() {
        super();
        this.form = this.querySelector('form');
        this.cart = document.querySelector('cart-drawer');
        this.submitButton = this.querySelector('[type="submit"]');
        this.hideErrors = this.dataset.hideErrors === 'true';
      
        // Enable the variant ID input
        const variantInput = this.form.querySelector('[name="id"]');
        if (variantInput) variantInput.disabled = false;
      
        this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
      
        // Set dialog attribute for accessibility if a cart drawer is present
        if (this.cart) {
          this.submitButton.setAttribute('aria-haspopup', 'dialog');
        }
      }

      onSubmitHandler(evt) {
        evt.preventDefault();
      
        if (this.isSubmitDisabled()) return;
      
        this.resetErrorState();
        this.toggleLoadingState(true);
      
        const config = this.prepareFetchConfig();
        const formData = this.getFormData();
      
        fetch(routes.cart_add_url, { ...config, body: formData })
          .then((response) => response.json())
          .then((response) => this.handleFetchResponse(response, formData))
          .catch((error) => {
            console.error('Error adding to cart:', error);
            this.displayError('An unexpected error occurred. Please try again.');
          })
          .finally(() => this.toggleLoadingState(false));
      }
      
      isSubmitDisabled() {
        return this.submitButton.getAttribute('aria-disabled') === 'true';
      }
      
      prepareFetchConfig() {
        const config = fetchConfig('javascript');
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        delete config.headers['Content-Type'];
        return config;
      }
      
      getFormData() {
        const formData = new FormData(this.form);
      
        if (this.cart) {
          formData.append(
            'sections',
            this.cart.getSectionsToRender().map((section) => section.id)
          );
          formData.append('sections_url', window.location.pathname);
          this.cart.setActiveElement(document.activeElement);
        }
      
        return formData;
      }
      
      handleFetchResponse(response, formData) {
        if (response.status) {
          this.handleCartError(response, formData);
          return;
        }
      
        if (!this.cart) {
          window.location = routes.cart_url;
          return;
        }
      
        publish(PUB_SUB_EVENTS.cartUpdate, {
          source: 'product-form',
          productVariantId: formData.get('id'),
          cartData: response,
        });
      
        this.updateCartContents(response);
      }
      
      handleCartError(response, formData) {
        publish(PUB_SUB_EVENTS.cartError, {
          source: 'product-form',
          productVariantId: formData.get('id'),
          errors: response.errors || response.description,
          message: response.message,
        });
      
        this.displayError(response.description);
      
        const soldOutMessage = this.submitButton.querySelector('.sold-out-message');
        if (soldOutMessage) {
          this.submitButton.setAttribute('aria-disabled', true);
          this.submitButton.querySelector('codes').classList.add('hidden');
          soldOutMessage.classList.remove('hidden');
        }
      
        this.error = true;
      }
      
      updateCartContents(response) {
        const quickAddModal = this.closest('product-add-popup');
        if (quickAddModal) {
          document.body.addEventListener(
            'modalClosed',
            () => this.cart.renderContents(response),
            { once: true }
          );
          quickAddModal.hide(true);
        } else {
          this.cart.renderContents(response);
        }
      }
      
      toggleLoadingState(isLoading) {
        this.submitButton.classList.toggle('loading', isLoading);
        const spinner = this.querySelector('.loading__spinner ');
        if (spinner) spinner.classList.toggle('hidden', !isLoading);
      
        if (isLoading) {
          this.submitButton.setAttribute('aria-disabled', true);
        } else {
          this.submitButton.removeAttribute('aria-disabled');
          if (this.cart && this.cart.classList.contains('is-empty')) {
            this.cart.classList.remove('is-empty');
          }
        }
      }
      
      resetErrorState() {
        this.error = false;
        const errorWrapper = this.querySelector('.validation-error-wrapper');
        if (errorWrapper) errorWrapper.setAttribute('hidden', true);
      }
      
      displayError(message) {
        const errorWrapper = this.querySelector('.validation-error-wrapper');
        const errorMessage = errorWrapper?.querySelector('.form-alert-error');
      
        if (errorWrapper && errorMessage) {
          errorWrapper.removeAttribute('hidden');
          errorMessage.textContent = message;
        }
      }
      
    
      handleError(errorMessage = false) {
        if (this.hideErrors) return;
        this.errorMessageWrapper ||= this.querySelector('.validation-error-wrapper');
        if (!this.errorMessageWrapper) return;
      
        this.errorMessage ||= this.errorMessageWrapper.querySelector('.form-alert-error');
    
        const isVisible = Boolean(errorMessage);
        this.errorMessageWrapper.toggleAttribute('hidden', !isVisible);
      
      
        if (isVisible) {
          this.errorMessage.textContent = errorMessage;
        }
      }

    }
  );
}
