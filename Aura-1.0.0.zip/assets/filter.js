class FacetFiltersForm extends HTMLElement {
  constructor() {
    super();
    this.onActiveFilterClick = this.onActiveFilterClick.bind(this);

    this.debouncedOnSubmit = debounce((event) => {
      this.onSubmitHandler(event);
    }, 800);

    const facetForm = this.querySelector("form");
    facetForm.addEventListener("input", this.debouncedOnSubmit.bind(this));

    const facetWrapper = this.querySelector("#FilterWrapperDesktop");
    if (facetWrapper) facetWrapper.addEventListener("keyup", onKeyUpEscape);
  }

  static setListeners() {
    const onHistoryChange = (event) => {
      const searchParams = event.state
        ? event.state.searchParams
        : FacetFiltersForm.searchParamsInitial;
      if (searchParams === FacetFiltersForm.searchParamsPrev) return;
      FacetFiltersForm.renderPage(searchParams, null, false);
    };
    window.addEventListener("popstate", onHistoryChange);
  }

  static toggleActiveFacets(disable = true) {
    document.querySelectorAll(".js-facet-remove").forEach((element) => {
      element.classList.toggle("disabled", disable);
    });
  }

  static renderPage(searchParams, event, updateURLHash = true) {
    FacetFiltersForm.searchParamsPrev = searchParams;
    const sections = FacetFiltersForm.getSections();
    const countContainer = document.getElementById("ProductCount");
    const countContainerDesktop = document.getElementById(
      "ProductCountDesktop"
    );
    const loadingSpinners = document.querySelectorAll(
      ".filter-container .loading__spinner, filters-form .loading__spinner"
    );
    loadingSpinners.forEach((spinner) => spinner.classList.remove("hidden"));
    document
      .getElementById("ProductGridWrapper")
      .querySelector(".collection")
      .classList.add("loading");
    if (countContainer) {
      countContainer.classList.add("loading");
    }
    if (countContainerDesktop) {
      countContainerDesktop.classList.add("loading");
    }

    sections.forEach((section) => {
      const url = `${window.location.pathname}?section_id=${section.section}&${searchParams}`;
      const filterDataUrl = (element) => element.url === url;

      FacetFiltersForm.filterData.some(filterDataUrl)
        ? FacetFiltersForm.renderSectionFromCache(filterDataUrl, event)
        : FacetFiltersForm.renderSectionFromFetch(url, event);
    });

    if (updateURLHash) FacetFiltersForm.updateURLHash(searchParams);
  }

  static renderSectionFromFetch(url, event) {
    fetch(url)
      .then((response) => response.text())
      .then((responseText) => {
        const html = responseText;
        FacetFiltersForm.filterData = [
          ...FacetFiltersForm.filterData,
          { html, url },
        ];
        FacetFiltersForm.renderFilters(html, event);
        FacetFiltersForm.renderProductGridWrapper(html);
        FacetFiltersForm.renderProductCount(html);
        if (typeof initializeScrollAnimationTrigger === "function")
          initializeScrollAnimationTrigger(html.innerHTML);
      });
  }

  static renderSectionFromCache(filterDataUrl, event) {
    const html = FacetFiltersForm.filterData.find(filterDataUrl).html;
    FacetFiltersForm.renderFilters(html, event);
    FacetFiltersForm.renderProductGridWrapper(html);
    FacetFiltersForm.renderProductCount(html);
    if (typeof initializeScrollAnimationTrigger === "function")
      initializeScrollAnimationTrigger(html.innerHTML);
  }

  static renderProductGridWrapper(html) {
    document.getElementById("ProductGridWrapper").innerHTML = new DOMParser()
      .parseFromString(html, "text/html")
      .getElementById("ProductGridWrapper").innerHTML;

    document
      .getElementById("ProductGridWrapper")
      .querySelectorAll(".scroll-trigger")
      .forEach((element) => {
        element.classList.add("scroll-trigger--cancel");
      });
  }

  static renderProductCount(html) {
    const count = new DOMParser()
      .parseFromString(html, "text/html")
      .getElementById("ProductCount").innerHTML;
    const container = document.getElementById("ProductCount");
    const containerDesktop = document.getElementById("ProductCountDesktop");
    container.innerHTML = count;
    container.classList.remove("loading");
    if (containerDesktop) {
      containerDesktop.innerHTML = count;
      containerDesktop.classList.remove("loading");
    }
    const loadingSpinners = document.querySelectorAll(
      ".filter-container .loading__spinner, filters-form .loading__spinner"
    );
    loadingSpinners.forEach((spinner) => spinner.classList.add("hidden"));
    
    // variantSwatches Tab
     var variantSwatches = document.querySelectorAll('.swatch_variant');
    variantSwatches.forEach(swatch =>{
      swatch.addEventListener('focus', ()=>{
        console.log('focused')
        swatch.closest('label').style.outline = '1px solid #000';
        swatch.closest('label').style.outlineOffset = '3px';
      });
  
      swatch.addEventListener('blur', ()=>{
        swatch.closest('label').style.outline = 'none';
      });
    });
  
    let buttons = document.querySelectorAll('.quick-add__submit');
    buttons.forEach(button =>{
      button.addEventListener('focus', ()=>{
        button.closest('.quick_action_wrapper').style.outline = '0.1rem solid #000';
        button.closest('.quick_action_wrapper').style.outlineOffset = '0.3rem';
      });
  
      button.addEventListener('blur', ()=>{
        button.closest('.quick_action_wrapper').style.outline = 'none';
      });
    });
  }

  static renderFilters(html, event) {
    const parsedHTML = new DOMParser().parseFromString(html, "text/html");

    const facetDetailsElementsFromFetch = parsedHTML.querySelectorAll(
      "#FacetFiltersForm .js-filter, #FacetFiltersFormMobile .js-filter, #FacetFiltersPillsForm .js-filter"
    );
    const facetDetailsElementsFromDom = document.querySelectorAll(
      "#FacetFiltersForm .js-filter, #FacetFiltersFormMobile .js-filter, #FacetFiltersPillsForm .js-filter"
    );

    // Remove filter that are no longer returned from the server
    Array.from(facetDetailsElementsFromDom).forEach((currentElement) => {
      if (
        !Array.from(facetDetailsElementsFromFetch).some(
          ({ id }) => currentElement.id === id
        )
      ) {
        currentElement.remove();
      }
    });

    const matchesId = (element) => {
      const jsFilter = event ? event.target.closest(".js-filter") : undefined;
      return jsFilter ? element.id === jsFilter.id : false;
    };

    const facetsToRender = Array.from(facetDetailsElementsFromFetch).filter(
      (element) => !matchesId(element)
    );
    const countsToRender = Array.from(facetDetailsElementsFromFetch).find(
      matchesId
    );

    facetsToRender.forEach((elementToRender, index) => {
      const currentElement = document.getElementById(elementToRender.id);
      // Element already rendered in the DOM so just update the innerHTML
      if (currentElement) {
        document.getElementById(elementToRender.id).innerHTML =
          elementToRender.innerHTML;
      } else {
        if (index > 0) {
          const { className: previousElementClassName, id: previousElementId } =
            facetsToRender[index - 1];
          // Same facet type (eg horizontal/vertical or drawer/mobile)
          if (elementToRender.className === previousElementClassName) {
            document.getElementById(previousElementId).after(elementToRender);
            return;
          }
        }

        if (elementToRender.parentElement) {
          document
            .querySelector(`#${elementToRender.parentElement.id} .js-filter`)
            .before(elementToRender);
        }
      }
    });

    FacetFiltersForm.renderActiveFacets(parsedHTML);
    FacetFiltersForm.renderAdditionalElements(parsedHTML);

    if (countsToRender) {
      const closestJSFilterID = event.target.closest(".js-filter").id;

      if (closestJSFilterID) {
        FacetFiltersForm.renderCounts(
          countsToRender,
          event.target.closest(".js-filter")
        );
        FacetFiltersForm.renderMobileCounts(
          countsToRender,
          document.getElementById(closestJSFilterID)
        );

        const newFacetDetailsElement =
          document.getElementById(closestJSFilterID);
        const newElementSelector = newFacetDetailsElement.classList.contains(
          "mobile-filter__details"
        )
          ? `.mobile-filter__close-button`
          : `.filter__summary`;
        const newElementToActivate =
          newFacetDetailsElement.querySelector(newElementSelector);

        const isTextInput = event.target.getAttribute("type") === "text";

        if (newElementToActivate && !isTextInput) newElementToActivate.focus();
      }
    }
  }



  static renderActiveFacets(html) {
  [".active-filter-mobile", ".active-filter-desktop"].forEach((selector) => {
    const source = html.querySelector(selector);
    const target = document.querySelector(selector);
    if (source && target) target.innerHTML = source.innerHTML;
  });

  FacetFiltersForm.toggleActiveFacets(false);
}


  static renderAdditionalElements(html) {
    const mobileElementSelectors = [
      ".mobile-filter__open",
      ".mobile-filter__count",
      ".sorting",
    ];

    mobileElementSelectors.forEach((selector) => {
      if (!html.querySelector(selector)) return;
      document.querySelector(selector).innerHTML =
        html.querySelector(selector).innerHTML;
    });

    document
      .getElementById("FacetFiltersFormMobile")
      .closest("menu-drawer")
      .bindEvents();
  }

  static renderCounts(source, target) {
    const targetSummary = target.querySelector(".filter__summary");
    const sourceSummary = source.querySelector(".filter__summary");

    if (sourceSummary && targetSummary) {
      targetSummary.outerHTML = sourceSummary.outerHTML;
    }

    const targetHeaderElement = target.querySelector(".filters__header");
    const sourceHeaderElement = source.querySelector(".filters__header");

    if (sourceHeaderElement && targetHeaderElement) {
      targetHeaderElement.outerHTML = sourceHeaderElement.outerHTML;
    }

    const targetWrapElement = target.querySelector(".filter-wrap");
    const sourceWrapElement = source.querySelector(".filter-wrap");

    if (sourceWrapElement && targetWrapElement) {
      const isShowingMore = Boolean(
        target.querySelector("show-more-button .label-show-more.hidden")
      );
      if (isShowingMore) {
        sourceWrapElement
          .querySelectorAll(".filter__item.hidden")
          .forEach((hiddenItem) =>
            hiddenItem.classList.replace("hidden", "show-more-item")
          );
      }

      targetWrapElement.outerHTML = sourceWrapElement.outerHTML;
    }
  }

  static renderMobileCounts(source, target) {
    const targetFacetsList = target.querySelector(".mobile-filter__list");
    const sourceFacetsList = source.querySelector(".mobile-filter__list");

    if (sourceFacetsList && targetFacetsList) {
      targetFacetsList.outerHTML = sourceFacetsList.outerHTML;
    }
  }

  static updateURLHash(searchParams) {
    history.pushState(
      { searchParams },
      "",
      `${window.location.pathname}${searchParams && "?".concat(searchParams)}`
    );
  }

  static getSections() {
    return [
      {
        section: document.getElementById("product-grid").dataset.id,
      },
    ];
  }

  createSearchParams(form) {
    const formData = new FormData(form);
    return new URLSearchParams(formData).toString();
  }

  onSubmitForm(searchParams, event) {
    FacetFiltersForm.renderPage(searchParams, event);
  }

  // onSubmitHandler 
  onSubmitHandler(event) {
    event.preventDefault();
    const sortFilterForms = document.querySelectorAll("filters-form form");
    if (event.srcElement.className == "mobile-filter__checkboxx") {
      const searchParams = this.createSearchParams(
        event.target.closest("form")
      );
      this.onSubmitForm(searchParams, event);
    } else {
      const forms = [];
      const isMobile =
        event.target.closest("form").id === "FacetFiltersFormMobile";

      sortFilterForms.forEach((form) => {
        if (!isMobile) {
          if (
            form.id === "FacetSortForm" ||
            form.id === "FacetFiltersForm" ||
            form.id === "FacetSortDrawerForm"
          ) {
            forms.push(this.createSearchParams(form));
          }
        } else if (form.id === "FacetFiltersFormMobile") {
          forms.push(this.createSearchParams(form));
        }
      });
      this.onSubmitForm(forms.join("&"), event);
    }
  }
  

  onActiveFilterClick(event) {
    event.preventDefault();
    FacetFiltersForm.toggleActiveFacets();
    const url =
      event.currentTarget.href.indexOf("?") == -1
        ? ""
        : event.currentTarget.href.slice(
            event.currentTarget.href.indexOf("?") + 1
          );
    FacetFiltersForm.renderPage(url);
  }
  
}

FacetFiltersForm.filterData = [];
FacetFiltersForm.searchParamsInitial = window.location.search.slice(1);
FacetFiltersForm.searchParamsPrev = window.location.search.slice(1);
customElements.define("filters-form", FacetFiltersForm);
FacetFiltersForm.setListeners();


// Filter Price
class PriceFilter extends HTMLElement {
  constructor() {
    super();
    this.querySelectorAll("input").forEach((element) => {
      element.addEventListener("change", this.onRangeChange.bind(this));
      element.addEventListener("keydown", this.onKeyDown.bind(this));
    });
    this.setMinAndMaxValues();
  }

  onRangeChange(event) {
    this.adjustToValidValues(event.currentTarget);
    this.setMinAndMaxValues();
  }

  onKeyDown(event) {
    if (event.metaKey) return;

    const pattern =
      /[0-9]|\.|,|'| |Tab|Backspace|Enter|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Delete|Escape/;
    if (!event.key.match(pattern)) event.preventDefault();
  }

  setMinAndMaxValues() {
    const inputs = this.querySelectorAll("input");
    const minInput = inputs[0];
    const maxInput = inputs[1];
    if (maxInput.value) minInput.setAttribute("data-max", maxInput.value);
    if (minInput.value) maxInput.setAttribute("data-min", minInput.value);
    if (minInput.value === "") maxInput.setAttribute("data-min", 0);
    if (maxInput.value === "")
      minInput.setAttribute("data-max", maxInput.getAttribute("data-max"));
  }

  adjustToValidValues(input) {
    const value = Number(input.value);
    const min = Number(input.getAttribute("data-min"));
    const max = Number(input.getAttribute("data-max"));

    if (value < min) input.value = min;
    if (value > max) input.value = max;
  }
}


customElements.define("price-range", PriceFilter);

// FilterRemove
class FilterRemove extends HTMLElement {
  constructor() {
    super();
    this.init();
  }

  init() {
    const facetLink = this.querySelector("a");
    if (facetLink) {
      facetLink.setAttribute("role", "button");
      facetLink.addEventListener("click", (event) => this.closeFilter(event));
      facetLink.addEventListener("keyup", (event) => this.handleKeyUp(event));
    }
  }

  handleKeyUp(event) {
    if (event.code.toUpperCase() === "SPACE") {
      event.preventDefault();
      this.closeFilter(event);
    }
  }

  closeFilter(event) {
    event.preventDefault();
    const form = this.closest("filters-form") || document.querySelector("filters-form");
    form?.onActiveFilterClick(event);
  }
}


customElements.define("filter-remove", FilterRemove);
