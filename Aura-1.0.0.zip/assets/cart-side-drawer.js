// This code is for cart drawer
class CartDrawer extends HTMLElement {
  constructor() {
    super();

    this.addEventListener(
      "keyup",
      (evt) => evt.code === "Escape" && this.close()
    );
    this.querySelector("#CartDrawer-Overlay").addEventListener(
      "click",
      this.close.bind(this)
    );
    this.setHeaderCartIconAccessibility();
  }

  setHeaderCartIconAccessibility() {
    const cartLink = document.querySelector(".header_cart_is_drawer") || document.querySelector(".header_cart");
    cartLink.setAttribute("role", "button");
    cartLink.setAttribute("aria-haspopup", "dialog");

    const openCart = (event) => {
      event.preventDefault();
      this.open(cartLink);
    };

    cartLink.addEventListener("click", openCart);
    cartLink.addEventListener("keydown", (event) => {
      if (event.code.toUpperCase() === "SPACE") openCart(event);
    });
  }

  open(triggeredBy) {
    if (triggeredBy) this.setActiveElement(triggeredBy);

    const cartDrawerNote = this.querySelector('[id^="Details-"] summary');
    if (cartDrawerNote && !cartDrawerNote.hasAttribute("role"))
      this.setSummaryAccessibility(cartDrawerNote);
    setTimeout(() => this.classList.add("animate", "active"));

    this.addEventListener(
      "transitionend",
      () => {
        const container = this.classList.contains("is-empty")
          ? this.querySelector(".drawer__empty-state")
          : document.getElementById("CartDrawer");
        trapFocus(
          container,
          this.querySelector(".drawer__inner") ||
            this.querySelector(".cart-close")
        );
      },
      { once: true }
    );

    //document.body.classList.add('overflow-hidden');
  }

  // close sidecart
  close() {
    this.classList.remove("active");
    removeTrapFocus(this.activeElement);
    //document.body.classList.remove('overflow-hidden');
  }

  // setSummaryAccessibility
  setSummaryAccessibility(cartDrawerNote) {
    cartDrawerNote.setAttribute("role", "button");
    cartDrawerNote.setAttribute("aria-expanded", "false");

    if (cartDrawerNote.nextElementSibling.getAttribute("id")) {
      cartDrawerNote.setAttribute(
        "aria-controls",
        cartDrawerNote.nextElementSibling.id
      );
    }

    cartDrawerNote.addEventListener("click", (event) => {
      event.currentTarget.setAttribute(
        "aria-expanded",
        !event.currentTarget.closest("details").hasAttribute("open")
      );
    });

    cartDrawerNote.parentElement.addEventListener("keyup", onKeyUpEscape);
  }

  renderContents(parsedState) {
    const drawerInner = this.querySelector(".drawer__inner");
    drawerInner.classList.contains("is-empty") &&
      drawerInner.classList.remove("is-empty");

    this.productId = parsedState.id;

    this.getSectionsToRender().forEach(({ id, selector }) => {
      const sectionElement = selector
        ? document.querySelector(selector)
        : document.getElementById(id);
      sectionElement.innerHTML = this.getSectionHTML(
        parsedState.sections[id],
        selector
      );
    });

    setTimeout(() => {
      this.querySelector("#CartDrawer-Overlay").addEventListener(
        "click",
        this.close.bind(this)
      );
      this.open();
    });
  }

  // getSectionHTML
  getSectionHTML(html, selector = ".shopify-section") {
    return new DOMParser()
      .parseFromString(html, "text/html")
      .querySelector(selector).innerHTML;
  }

  getSectionsToRender() {
    return [
      { id: "cart-drawer", selector: "#CartDrawer" },
      { id: "cart-icon-bubble" },
    ];
  }

  getSectionDOM(html, selector = ".shopify-section") {
    return new DOMParser()
      .parseFromString(html, "text/html")
      .querySelector(selector);
  }

  setActiveElement(element) {
    this.activeElement = element;
  }
}

customElements.define("cart-drawer", CartDrawer);

class CartDrawerItems extends CartItems {
  getSectionsToRender() {
    return [
      {
        id: "CartDrawer",
        section: "cart-drawer",
        selector: ".drawer__inner",
      },
      {
        id: "cart-icon-bubble",
        section: "cart-icon-bubble",
        selector: ".shopify-section",
      },
    ];
  }
}

customElements.define("cart-item-list", CartDrawerItems);
