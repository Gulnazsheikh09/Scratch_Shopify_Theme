if (!customElements.get('show-more-button')) {
  customElements.define(
    'show-more-button',
    class ShowMoreButton extends HTMLElement {
      constructor() {
        super();
        this.init();
      }

      init() {
        const button = this.querySelector('button');
        if (button) {
          button.addEventListener('click', () => this.handleButtonClick());
        }
      }

      handleButtonClick() {
        const parent = this.closest('.parent-display');
        const items = parent?.querySelectorAll('.show-more-item');
        const labels = this.querySelectorAll('.label-text');
        const hasShowLess = this.querySelector('.label-show-less');

        // Toggle hidden class on labels and items
        labels.forEach((label) => label.classList.toggle('hidden'));
        items?.forEach((item) => item.classList.toggle('hidden'));

        // Hide the button if no "show less" label exists
        if (!hasShowLess) {
          this.classList.add('hidden');
        }

        // Focus on the first visible item if available
        const firstFocusable = parent?.querySelector('.show-more-item:not(.hidden) input');
        firstFocusable?.focus();
      }
    }
  );
}

