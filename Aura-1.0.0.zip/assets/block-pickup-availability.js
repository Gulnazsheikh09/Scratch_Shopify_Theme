if (!customElements.get("pickup-available")) {
  customElements.define(
    "pickup-available",

    class PickupAvailable extends HTMLElement {
      constructor() {
        super();

        if (!this.hasAttribute("available")) return;

        this.errorHtml =
          this.querySelector("template").content.firstElementChild.cloneNode(
            true
          );
        this.onClickRefreshRow = this.onClickRefreshRow.bind(this);
        this.fetchAvailability_product(this.dataset.variantId);
      }

      fetchAvailability_product(variantId) {
        let rootUrl = this.dataset.rootUrl;
        if (!rootUrl.endsWith("/")) {
          rootUrl = rootUrl + "/";
        }
        const variantSectionLink = `${rootUrl}variants/${variantId}/?section_id=pickup-availability`;

        fetch(variantSectionLink)
          .then((response) => response.text())
          .then((text) => {
            const sectionInnerHTML = new DOMParser()
              .parseFromString(text, "text/html")
              .querySelector(".shopify-section");
            this.renderPreviewList(sectionInnerHTML);
          })
          .catch((e) => {
            const button = this.querySelector("button");
            if (button)
              button.removeEventListener("click", this.onClickRefreshRow);
            this.renderError_block();
          });
      }

      onClickRefreshRow(evt) {
        this.fetchAvailability_product(this.dataset.variantId);
      }

      renderError_block() {
        this.innerHTML = "";
        this.appendChild(this.errorHtml);

        const button = this.querySelector("button");
        if (button) {
          button.addEventListener("click", this.onClickRefreshRow);
        }
      }

      renderPreviewList(sectionInnerHTML) {
        const drawer = document.querySelector("pickup-availability-popup");
        if (drawer) drawer.remove();

        const viewElement = sectionInnerHTML.querySelector(
          "pickup-availability-view"
        );
        if (!viewElement) {
          this.innerHTML = "";
          this.removeAttribute("available");
          return;
        }

        this.innerHTML = viewElement.outerHTML;
        this.setAttribute("available", "");

        const popup = sectionInnerHTML.querySelector(
          "pickup-availability-popup"
        );
        document.body.appendChild(popup);
        this.classList.add("loaded");

        // Apply color classes
        const colorClasses = this.dataset.productPageColorScheme.split(" ");
        colorClasses.forEach((colorClass) => {
          popup.classList.add(colorClass);
        });

        // Button event listener
        const button = this.querySelector("button");
        if (button) {
          button.addEventListener("click", (evt) => {
            popup.show(evt.target);
            document
              .querySelector("pickup-availability-popup")
              .setAttribute("open", "");
          });
        }

        popup.addEventListener("click", (evt) => {
          popup.hide(evt.target);
        });

        document
          .querySelector(".availability-drawer-inner")
          .addEventListener("click", (e) => {
            e.stopPropagation();
          });
      }
    }
  );
}
// pickup-availability-popup //
if (!customElements.get("pickup-availability-popup")) {
  customElements.define(
    "pickup-availability-popup",
    class PickupAvailabilityDrawer extends HTMLElement {
      constructor() {
        super();
        this.onBodyClick = this.handleBodyClick.bind(this);
      }

      connectedCallback() {
        this.querySelector("button").addEventListener("click", () =>
          this.hide()
        );
        this.addEventListener("keyup", (event) => {
          if (event.code.toUpperCase() === "ESCAPE") this.hide();
        });
      }

      handleBodyClick(evt) {
        if (
          !this.contains(evt.target) &&
          evt.target.id !== "ShowPickupAvailabilityDrawer"
        ) {
          this.hide();
        }
      }

      hide() {
        this.removeAttribute("open");
        document.body.removeEventListener("click", this.onBodyClick);
        removeTrapFocus(this.focusElement);
      }

      show(focusElement) {
        this.focusElement = focusElement;
        this.setAttribute("open", "");
        document.querySelector("pickup-availabitlity-popup");
        document.body.addEventListener("click", this.onBodyClick);
        trapFocus(this);

        let cursors = document.querySelectorAll(".cursor");

        document.addEventListener("mousemove", function (e) {
          let left = e.clientX + "px";
          let top = e.clientY + "px";

          cursors.forEach(function (cursor) {
            cursor.style.left = left;
            cursor.style.top = top;
            // cursor.style.transform = "translate(-" + left + ", -" + top + ")";
          });
        });
      }
    }
  );
}
