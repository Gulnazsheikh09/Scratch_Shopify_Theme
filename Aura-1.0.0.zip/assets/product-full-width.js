if ($(window).width() > 749) {
  document.addEventListener("DOMContentLoaded", function () {
    // Function to initialize Swiper
    function initializeSwiper(selector, nextBtn, prevBtn) {
      if (document.querySelector(selector)) {
        return new Swiper(selector, {
          slidesPerView: 4,
          spaceBetween: 20,
          loop: false,
          navigation: {
            nextEl: nextBtn,
            prevEl: prevBtn,
          },
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
          breakpoints: {
            1024: { slidesPerView: 4 },
            768: { slidesPerView: 2 },
            480: { slidesPerView: 1 },
          },
          on: {
            // Disable dragging if a video is present in the active slide
            slideChange: function () {
              let activeSlide = this.slides[this.activeIndex];
              if (activeSlide.querySelector("video")) {
                this.allowTouchMove = false;
              } else {
                this.allowTouchMove = true;
              }
            },
          },
        });
      }
      return null;
    }

    // Initialize Swipers
    var fullSwiper = initializeSwiper(".slider-component-full", ".swiper-full-button-next", ".swiper-full-button-prev");
    var modelSwiper = initializeSwiper(".product-model", ".swiper-model-button-next", ".swiper-model-button-prev");

    // Click event to move Swipers to the first slide
    document.querySelectorAll(".var-opt label").forEach((label) => {
      label.addEventListener("click", function () {
        if (fullSwiper) fullSwiper.slideTo(0);
        if (modelSwiper) modelSwiper.slideTo(0);
      });
    });
  });
}
