if (!customElements.get('product-object')) {
  customElements.define(
    'product-object',
    class ProductObj extends HTMLElement {
      constructor() {
        super();
        this.input = this.querySelector('.quantity__input'); // Get the quantity input element
        this.currentVariant = this.querySelector('.product-variant-id'); // Get the current product variant element
        this.submitButton = this.querySelector('[type="submit"]'); // Get the submit button
        this.cartUpdateUnsubscriber = undefined; // Placeholder for the cart update event unsubscribe function
        this.variantChangeUnsubscriber = undefined; // Placeholder for the variant change event unsubscribe function
      }
    
      // Called when the element is inserted into the DOM
      connectedCallback() {
        if (this.input && this.querySelector('.product-form__quantity')) {
          this.setQuantityBoundries(); // Initialize quantity boundaries
          this.subscribeToEvents(); // Subscribe to relevant events
        }
      }
    
      // Called when the element is removed from the DOM
      disconnectedCallback() {
        this.unsubscribeFromEvents(); // Unsubscribe from all events
      }
    
      // Subscribes to cart update and variant change events
      subscribeToEvents() {
        if (!this.dataset.originalSection) {
          this.cartUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.cartUpdate, this.fetchQuantityRules.bind(this));
        }
    
        // Listen for changes to the product variant
        this.variantChangeUnsubscriber = subscribe(PUB_SUB_EVENTS.variantChange, this.handleVariantChange.bind(this));
      }
    
      // Unsubscribes from all events to avoid memory leaks
      unsubscribeFromEvents() {
        // If the unsubscribe function exists, call it to remove the event listener
        this.cartUpdateUnsubscriber?.();
        this.variantChangeUnsubscriber?.();
      }
    
      // Handles variant change event
      handleVariantChange(event) {
        // Check if the event is relevant to the current section
        if (this.isRelevantVariant(event)) {
          this.updateQuantityRules(event.data.sectionId, event.data.html); // Update quantity rules based on the new variant
          this.setQuantityBoundries(); // Recalculate the quantity boundaries
        }
      }
    
      // Checks if the variant change event corresponds to the current section
      isRelevantVariant(event) {
        return event.data.sectionId === this.dataset.originalSection || event.data.sectionId === this.dataset.section;
      }
    
      // Set the quantity boundaries for the input field based on data attributes
      setQuantityBoundries() {
        const data = this.parseQuantityData(); // Parse data attributes
        let min = data.min;
        const max = data.max === null ? data.max : data.max - data.cartQuantity; // Adjust max based on cart quantity
    
        if (max !== null) min = Math.min(min, max); // Ensure min does not exceed max
        if (data.cartQuantity >= data.min) min = Math.min(min, data.step); // Ensure min respects step
    
        this.input.min = min; // Set the min value for the input field
        this.input.max = max !== null ? max : undefined; // Set max value if defined, otherwise remove it
        this.input.value = min; // Set the initial value of the input field
        publish(PUB_SUB_EVENTS.quantityUpdate, undefined); // Publish a quantity update event
      }
    
      // Parses the quantity data from the input element's dataset
      parseQuantityData() {
        return {
          cartQuantity: parseInt(this.input.dataset.cartQuantity || 0), // Default to 0 if not provided
          min: parseInt(this.input.dataset.min || 1), // Default to 1 if not provided
          max: this.input.dataset.max ? parseInt(this.input.dataset.max) : null, // Default to null if not provided
          step: parseInt(this.input.step || 1) // Default to 1 if not provided
        };
      }
    
      // Fetches quantity rules from the server based on the current product variant
      fetchQuantityRules() {
        if (!this.currentVariant?.value) return; // Exit if there's no variant selected
    
        this.toggleLoadingSpinner(true); // Show loading spinner
        fetch(`${this.dataset.url}?variant=${this.currentVariant.value}&section_id=${this.dataset.section}`)
          .then((response) => response.text()) // Get the response as text
          .then((responseText) => {
            const html = new DOMParser().parseFromString(responseText, 'text/html'); // Parse the response HTML
            this.updateQuantityRules(this.dataset.section, html); // Update the quantity rules with the new data
            this.setQuantityBoundries(); // Recalculate the quantity boundaries
          })
          .catch((e) => console.error(e)) // Log errors to the console
          .finally(() => this.toggleLoadingSpinner(false)); // Hide the loading spinner when done
      }
    
      // Toggles the visibility of the loading spinner
      toggleLoadingSpinner(isLoading) {
        const spinner = this.querySelector('.quantity__rules-cart .loading__spinner');
        if (spinner) {
          spinner.classList.toggle('hidden', !isLoading); // Add or remove the 'hidden' class based on the loading state
        }
      }
    
      // Updates the quantity rules based on the new HTML
      updateQuantityRules(sectionId, html) {
        const quantityFormUpdated = html.getElementById(`Quantity-Form-${sectionId}`);
        // Iterate through the relevant selectors and update the current form's elements
        ['.quantity__input', '.quantity__rules', '.quantity__label'].forEach(selector => {
          const current = this.quantityForm.querySelector(selector); // Get the current element
          const updated = quantityFormUpdated.querySelector(selector); // Get the updated element
          if (!current || !updated) return; // Skip if either element is missing
    
          this.updateAttributes(selector, current, updated); // Update the element's attributes or innerHTML
        });
      }
    
      // Updates attributes or innerHTML of the elements
      updateAttributes(selector, current, updated) {
        if (selector === '.quantity__input') {
          // Update attributes for quantity input elements
          ['data-cart-quantity', 'data-min', 'data-max', 'step'].forEach(attribute => {
            const valueUpdated = updated.getAttribute(attribute);
            if (valueUpdated !== null) {
              current.setAttribute(attribute, valueUpdated); // Update attribute if it exists
            } else {
              current.removeAttribute(attribute); // Remove the attribute if it's null
            }
          });
        } else {
          current.innerHTML = updated.innerHTML; // Update the innerHTML of other elements
        }
      }
    }
    
  );
}
