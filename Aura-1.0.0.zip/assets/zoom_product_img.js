document.addEventListener("DOMContentLoaded", function () {
  const zoomContainers = document.querySelectorAll(".zoom-container"); // Select all zoom containers
  const zoomScale = 2; // Zoom factor

  zoomContainers.forEach(container => {
    const image = container.querySelector(".zoom-image");
    let zoomedIn = false;
    let lastTap = 0;

    function positionFunc(event) {
      const rect = container.getBoundingClientRect();
      let x, y;

      if (event.touches) {
        // Handle touch events
        x = event.touches[0].clientX - rect.left;
        y = event.touches[0].clientY - rect.top;
      } else {
        // Handle mouse events
        x = event.clientX - rect.left;
        y = event.clientY - rect.top;
      }

      return { x, y };
    }

    function zoomIn(event) {
      const { x, y } = positionFunc(event);

      // Calculate transform origin
      const offsetX = (x / container.offsetWidth) * 100;
      const offsetY = (y / container.offsetHeight) * 100;

      // Apply zoom
      image.style.transform = `scale(${zoomScale})`;
      image.style.transformOrigin = `${offsetX}% ${offsetY}%`;
      image.style.transition = "transform 0.3s ease";
      container.style.cursor = "move";

      zoomedIn = true;
    }

    function zoomOut() {
      // Reset image scale and position
      image.style.transform = "scale(1)";
      image.style.transformOrigin = "center";
      image.style.left = "0";
      image.style.top = "0";
      container.style.cursor = "zoom-in";

      zoomedIn = false;
    }

    function handleDoubleTap(event) {
      const currentTime = new Date().getTime();
      const tapInterval = currentTime - lastTap;

      if (tapInterval < 300 && tapInterval > 0) { // Double-tap detected
        if (zoomedIn) {
          zoomOut();
        } else {
          zoomIn(event);
        }
      }
      lastTap = currentTime;
    }

    function handleTouchMove(event) {
      if (!zoomedIn) return;
      event.preventDefault();

      const { x, y } = positionFunc(event);

      // Calculate relative movement
      const offsetX = ((x / container.offsetWidth) - 0.5) * 100;
      const offsetY = ((y / container.offsetHeight) - 0.5) * 100;

      image.style.left = `${offsetX * (zoomScale - 1)}%`;
      image.style.top = `${offsetY * (zoomScale - 1)}%`;
    }

    // Event listeners for desktop
    container.addEventListener("click", function (event) {
      if (!('ontouchstart' in window)) { // Ensure this is for desktop
        if (zoomedIn) {
          zoomOut();
        } else {
          zoomIn(event);
        }
      }
    });

    container.addEventListener("mousemove", function (event) {
      if (!('ontouchstart' in window)) { // Ensure this is for desktop
        if (zoomedIn) {
          const { x, y } = positionFunc(event);
          const offsetX = ((x / container.offsetWidth) - 0.5) * 100;
          const offsetY = ((y / container.offsetHeight) - 0.5) * 100;

          image.style.left = `${offsetX * (zoomScale - 1)}%`;
          image.style.top = `${offsetY * (zoomScale - 1)}%`;
        }
      }
    });

    container.addEventListener("mouseleave", function () {
      if (!('ontouchstart' in window)) { // Ensure this is for desktop
        zoomOut();
      }
    });

    // Event listeners for touch (mobile)
    container.addEventListener("touchstart", handleDoubleTap);
    container.addEventListener("touchmove", handleTouchMove);
    container.addEventListener("touchend", function () {
      if (zoomedIn) zoomOut();
    });
  });
});
